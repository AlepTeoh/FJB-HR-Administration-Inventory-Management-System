<?php
// actions/training.php  — v3: training_type support
require_once '../includes/auth.php';
require_once '../includes/config.php';

// ── AJAX: Staff search ─────────────────────────────────────────────────
if (isset($_GET['search_staff'])) {
    requireLogin();
    $pdo = getDB();
    $q   = '%' . trim($_GET['search_staff']) . '%';
    $stmt = $pdo->prepare("
        SELECT s.id, s.staff_no, s.name, d.name AS dept_name
        FROM staff s
        LEFT JOIN departments d ON s.department_id = d.id
        WHERE s.name LIKE ? OR s.staff_no LIKE ?
        ORDER BY s.name LIMIT 20
    ");
    $stmt->execute([$q, $q]);
    header('Content-Type: application/json');
    echo json_encode($stmt->fetchAll());
    exit;
}

requireLogin();
$pdo    = getDB();
$action = $_POST['action'] ?? '';

// ── Add Course ─────────────────────────────────────────────────────────
if ($action === 'add_course' && isAdmin()) {
    $trainingType = in_array($_POST['training_type'] ?? '', ['External','Internal'])
                    ? $_POST['training_type'] : 'External';

    // Check if training_type column exists (graceful for un-migrated DBs)
    try {
        $stmt = $pdo->prepare("
            INSERT INTO training_courses (code, training_type, title, company, training_date)
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            strtoupper(trim($_POST['code'])),
            $trainingType,
            trim($_POST['title']),
            $_POST['company'] ?? 'FJB',
            $_POST['training_date'] ?: null,
        ]);
    } catch (\PDOException $e) {
        // Fallback: column may not exist yet
        $stmt = $pdo->prepare("INSERT INTO training_courses (code, title, company, training_date) VALUES (?,?,?,?)");
        $stmt->execute([
            strtoupper(trim($_POST['code'])),
            trim($_POST['title']),
            $_POST['company'] ?? 'FJB',
            $_POST['training_date'] ?: null,
        ]);
    }
    redirect('saved');
}

// ── Add Attendance ─────────────────────────────────────────────────────
if ($action === 'add_attendance' && isAdmin()) {
    $staffId  = (int)$_POST['staff_id'];
    $courseId = (int)$_POST['course_id'];
    $status   = $_POST['status'] ?? 'Completed';
    $remarks  = trim($_POST['remarks'] ?? '');
    $userId   = currentUser()['id'];

    // Resolve training_type from course
    $tcStmt = $pdo->prepare("SELECT COALESCE(training_type,'External') AS tt FROM training_courses WHERE id = ?");
    $tcStmt->execute([$courseId]);
    $trainingType = $tcStmt->fetchColumn() ?: 'External';

    try {
        $stmt = $pdo->prepare("
            INSERT IGNORE INTO training_attendances
                (staff_id, course_id, status, training_type, remarks, created_by)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$staffId, $courseId, $status, $trainingType, $remarks, $userId]);
    } catch (\PDOException $e) {
        // Fallback without training_type
        $stmt = $pdo->prepare("INSERT IGNORE INTO training_attendances (staff_id, course_id, status, remarks, created_by) VALUES (?,?,?,?,?)");
        $stmt->execute([$staffId, $courseId, $status, $remarks, $userId]);
    }
    redirect('saved');
}

// ── Edit Attendance ────────────────────────────────────────────────────
if ($action === 'edit_attendance' && isAdmin()) {
    $stmt = $pdo->prepare("UPDATE training_attendances SET status=?, remarks=? WHERE id=?");
    $stmt->execute([$_POST['status'], trim($_POST['remarks'] ?? ''), (int)$_POST['id']]);
    redirect('saved');
}

// ── Delete Attendance ──────────────────────────────────────────────────
if ($action === 'delete_attendance' && isAdmin()) {
    $stmt = $pdo->prepare("DELETE FROM training_attendances WHERE id=?");
    $stmt->execute([(int)$_POST['id']]);
    redirect('deleted');
}

function redirect($toast, $type = 'success') {
    header("Location: ../dashboard.php?page=training&toast=$toast&toast_type=$type");
    exit;
}
