<?php
// actions/booking.php
require_once '../includes/auth.php';
require_once '../includes/config.php';
require_once '../includes/migrate.php';
requireLogin();

$pdo    = getDB();
$action = $_POST['action'] ?? '';
$user   = currentUser();
$redirectDate = $_POST['redirect_date'] ?? date('Y-m-d');

// Run migrations once at the top — adds any missing columns safely
migrateBookingColumns($pdo);

// Helper: is current user PIC for a given room?
function isPicForRoom($pdo, $roomId, $userId) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM meeting_rooms WHERE id = ? AND pic_user_id = ?");
    $stmt->execute([$roomId, $userId]);
    return (int)$stmt->fetchColumn() > 0;
}

// ── ROOM MANAGEMENT ─────────────────────────────────────────────────

if ($action === 'add_room') {
    requireAdminIT();
    $name        = trim($_POST['room_name'] ?? '');
    $description = trim($_POST['room_description'] ?? '');
    $capacity    = max(1, (int)($_POST['room_capacity'] ?? 1));
    $color       = $_POST['room_color'] ?? 'room-blue';
    $picUserId   = !empty($_POST['room_pic']) ? (int)$_POST['room_pic'] : null;
    $allowed     = ['room-red','room-blue','room-yellow','room-green','room-purple','room-orange'];
    if (!$name || !in_array($color, $allowed)) redirect('error', $redirectDate);
    $stmt = $pdo->prepare("INSERT INTO meeting_rooms (name, description, capacity, color_class, pic_user_id) VALUES (?,?,?,?,?)");
    $stmt->execute([$name, $description, $capacity, $color, $picUserId]);
    redirect('room_added', $redirectDate);
}

if ($action === 'edit_room') {
    requireAdminIT();
    $roomId      = (int)($_POST['room_id'] ?? 0);
    $name        = trim($_POST['room_name'] ?? '');
    $description = trim($_POST['room_description'] ?? '');
    $capacity    = max(1, (int)($_POST['room_capacity'] ?? 1));
    $color       = $_POST['room_color'] ?? 'room-blue';
    $picUserId   = !empty($_POST['room_pic']) ? (int)$_POST['room_pic'] : null;
    $allowed     = ['room-red','room-blue','room-yellow','room-green','room-purple','room-orange'];
    if (!$roomId || !$name || !in_array($color, $allowed)) redirect('error', $redirectDate);
    $stmt = $pdo->prepare("UPDATE meeting_rooms SET name=?, description=?, capacity=?, color_class=?, pic_user_id=? WHERE id=?");
    $stmt->execute([$name, $description, $capacity, $color, $picUserId, $roomId]);
    redirect('room_updated', $redirectDate);
}

if ($action === 'delete_room') {
    requireAdminIT();
    $roomId = (int)($_POST['room_id'] ?? 0);
    if (!$roomId) redirect('error', $redirectDate);
    $pdo->prepare("DELETE FROM room_bookings WHERE room_id = ?")->execute([$roomId]);
    $pdo->prepare("DELETE FROM meeting_rooms WHERE id = ?")->execute([$roomId]);
    redirect('room_deleted', $redirectDate);
}

// ── BOOKING ACTIONS ──────────────────────────────────────────────────

if ($action === 'add') {
    $stmt = $pdo->prepare("
        INSERT INTO room_bookings (room_id, booked_by_id, booked_by_name, booking_date, start_time, end_time, purpose, status)
        VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending')
    ");
    $stmt->execute([
        (int)$_POST['room_id'],
        $user['id'],
        $user['name'],
        $_POST['booking_date'],
        $_POST['start_time'],
        $_POST['end_time'],
        trim($_POST['purpose']),
    ]);
    redirect('booked', $redirectDate);
}

if ($action === 'edit') {
    $id = (int)$_POST['id'];
    $stmt = $pdo->prepare("SELECT booked_by_id, status FROM room_bookings WHERE id = ?");
    $stmt->execute([$id]);
    $booking = $stmt->fetch();
    $currentStatus = $booking['status'] ?? 'Pending';
    // Only owner can edit, only while Pending
    if (!$booking || $booking['booked_by_id'] != $user['id'] || $currentStatus !== 'Pending') {
        redirect('error', $redirectDate);
    }
    $stmt = $pdo->prepare("
        UPDATE room_bookings SET room_id=?, booking_date=?, start_time=?, end_time=?, purpose=?, status='Pending'
        WHERE id=?
    ");
    $stmt->execute([
        (int)$_POST['room_id'],
        $_POST['booking_date'],
        $_POST['start_time'],
        $_POST['end_time'],
        trim($_POST['purpose']),
        $id,
    ]);
    redirect('updated', $redirectDate);
}

if ($action === 'delete') {
    $id = (int)$_POST['id'];
    $stmt = $pdo->prepare("SELECT booked_by_id FROM room_bookings WHERE id = ?");
    $stmt->execute([$id]);
    $booking = $stmt->fetch();
    // Only the owner can cancel their own booking
    if (!$booking || $booking['booked_by_id'] != $user['id']) {
        redirect('error', $redirectDate);
    }
    $pdo->prepare("DELETE FROM room_bookings WHERE id = ?")->execute([$id]);
    redirect('cancelled', $redirectDate);
}

if ($action === 'approve') {
    $id = (int)$_POST['id'];
    $stmt = $pdo->prepare("SELECT room_id, status FROM room_bookings WHERE id = ?");
    $stmt->execute([$id]);
    $booking = $stmt->fetch();
    $currentStatus = $booking['status'] ?? 'Pending';
    if (!$booking || $currentStatus === 'Approved' || $currentStatus === 'Rejected') redirect('error', $redirectDate);
    if (!isAdminIT() && !isPicForRoom($pdo, $booking['room_id'], $user['id'])) {
        redirect('error', $redirectDate);
    }
    $stmt = $pdo->prepare("
        UPDATE room_bookings
        SET status='Approved', approved_by_id=?, approved_by_name=?, approved_at=NOW()
        WHERE id=?
    ");
    $stmt->execute([$user['id'], $user['name'], $id]);
    redirect('approved', $redirectDate);
}

if ($action === 'reject') {
    $id     = (int)$_POST['id'];
    $reason = trim($_POST['rejection_reason'] ?? '');
    $stmt = $pdo->prepare("SELECT room_id, status FROM room_bookings WHERE id = ?");
    $stmt->execute([$id]);
    $booking = $stmt->fetch();
    $currentStatus = $booking['status'] ?? 'Pending';
    if (!$booking || $currentStatus === 'Approved' || $currentStatus === 'Rejected') redirect('error', $redirectDate);
    if (!isAdminIT() && !isPicForRoom($pdo, $booking['room_id'], $user['id'])) {
        redirect('error', $redirectDate);
    }
    $stmt = $pdo->prepare("
        UPDATE room_bookings
        SET status='Rejected', approved_by_id=?, approved_by_name=?, approved_at=NOW(), rejection_reason=?
        WHERE id=?
    ");
    $stmt->execute([$user['id'], $user['name'], $reason, $id]);
    redirect('rejected', $redirectDate);
}

function redirect($toast, $date) {
    header("Location: ../dashboard.php?page=rooms&date=" . urlencode($date) . "&toast=$toast&toast_type=success");
    exit;
}
