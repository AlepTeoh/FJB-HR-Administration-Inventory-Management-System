<?php
require_once '../includes/auth.php';
require_once '../includes/config.php';
requireAdminIT();
$pdo = getDB();
$action = $_POST['action'] ?? '';

// --- Staff registry AJAX search (GET) ---
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $staffId = trim($_GET['sr_staffid'] ?? '');
    $name    = trim($_GET['sr_name'] ?? '');
    $deptId  = (int)($_GET['sr_dept'] ?? 0);

    $where = []; $params = [];
    if ($staffId) { $where[] = "s.staff_no LIKE ?"; $params[] = "%$staffId%"; }
    if ($name)    { $where[] = "s.name LIKE ?";     $params[] = "%$name%"; }
    if ($deptId)  { $where[] = "s.department_id = ?"; $params[] = $deptId; }
    if (!$where)  { header('Content-Type: application/json'); echo '[]'; exit; }

    $sql = "SELECT s.id, s.staff_no, s.name, s.position, s.email, s.department_id,
                   d.name as dept_name
            FROM staff s
            LEFT JOIN departments d ON s.department_id = d.id
            WHERE s.is_active = 1 AND (" . implode(' OR ', $where) . ")
            ORDER BY s.name LIMIT 50";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    header('Content-Type: application/json');
    echo json_encode($stmt->fetchAll());
    exit;
}

if ($action === 'add') {
    $pw = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (name,email,password,role,staff_no,department_id,position,company) VALUES (?,?,?,?,?,?,?,?)");
    $stmt->execute([trim($_POST['name']),trim($_POST['email']),$pw,$_POST['role'],trim($_POST['staff_no']??''),($_POST['department_id']?:null),trim($_POST['position']??''),'FJB']);
    redirect('saved');
}
if ($action === 'edit') {
    if (!empty($_POST['password'])) {
        $pw = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE users SET name=?,email=?,password=?,role=?,staff_no=?,department_id=?,position=? WHERE id=?");
        $stmt->execute([trim($_POST['name']),trim($_POST['email']),$pw,$_POST['role'],trim($_POST['staff_no']??''),($_POST['department_id']?:null),trim($_POST['position']??''),(int)$_POST['id']]);
    } else {
        $stmt = $pdo->prepare("UPDATE users SET name=?,email=?,role=?,staff_no=?,department_id=?,position=? WHERE id=?");
        $stmt->execute([trim($_POST['name']),trim($_POST['email']),$_POST['role'],trim($_POST['staff_no']??''),($_POST['department_id']?:null),trim($_POST['position']??''),(int)$_POST['id']]);
    }
    redirect('saved');
}
if ($action === 'delete') {
    $pdo->prepare("DELETE FROM users WHERE id=?")->execute([(int)$_POST['id']]);
    redirect('deleted');
}
function redirect($t) { header("Location: ../dashboard.php?page=users&toast=$t&toast_type=success"); exit; }
