<?php
// pages/training.php  — v3: External/Internal filter + live search + totals
require_once __DIR__ . '/../includes/config.php';
$pdo  = getDB();
$user = currentUser();

$view        = $_GET['view'] ?? (isAdmin() ? 'by_dept' : 'list');
if (!isAdmin() && $view !== 'list') $view = 'list';

$dept_filter = $_GET['dept']    ?? '';
$company_f   = $_GET['company'] ?? '';
$search      = $_GET['q']       ?? '';
$course_id   = isset($_GET['course_id']) ? (int)$_GET['course_id'] : 0;
$status_f    = $_GET['status']  ?? '';
$type_filter = $_GET['type']    ?? '';   // NEW: External | Internal | ''

$allDepts   = $pdo->query("SELECT * FROM departments ORDER BY company, name")->fetchAll();
$allCourses = $pdo->query("SELECT * FROM training_courses ORDER BY code")->fetchAll();

// ── Training-type totals (global, used in summary bar) ─────────────────
$typeTotals = $pdo->query("
    SELECT
        COUNT(*)                                      AS grand_total,
        SUM(ta.training_type = 'External')            AS ext_total,
        SUM(ta.training_type = 'Internal')            AS int_total,
        COUNT(DISTINCT ta.staff_id)                   AS unique_staff,
        COUNT(DISTINCT ta.course_id)                  AS unique_courses
    FROM training_attendances ta
")->fetch();

// ── BY-DEPT view ────────────────────────────────────────────────────────
if ($view === 'by_dept') {
    $conds = []; $params = [];
    if ($dept_filter) { $conds[] = 'd.id = ?';      $params[] = $dept_filter; }
    if ($company_f)   { $conds[] = 'd.company = ?'; $params[] = $company_f;   }
    $where = $conds ? 'WHERE '.implode(' AND ',$conds) : '';

    $typeJoin = '';
    $typeWhere = '';
    if ($type_filter) {
        $typeJoin  = '';
        $typeWhere = "AND ta.training_type = " . $pdo->quote($type_filter);
    }

    $stmt = $pdo->prepare("
        SELECT d.*,
               COUNT(DISTINCT s.id)                              AS staff_count,
               COUNT(DISTINCT ta.id)                             AS training_count,
               SUM(ta.training_type = 'External')                AS ext_count,
               SUM(ta.training_type = 'Internal')                AS int_count,
               COUNT(DISTINCT ta.course_id)                      AS unique_courses
        FROM departments d
        LEFT JOIN staff s              ON s.department_id = d.id
        LEFT JOIN training_attendances ta ON ta.staff_id = s.id
        $where
        GROUP BY d.id
        ORDER BY d.company, d.name
    ");
    $stmt->execute($params);
    $dept_summaries = $stmt->fetchAll();
}

// ── COURSE-ATTENDEES view ───────────────────────────────────────────────
if ($view === 'course' && $course_id) {
    $course = $pdo->prepare("SELECT * FROM training_courses WHERE id = ?");
    $course->execute([$course_id]);
    $course = $course->fetch();

    $stmt = $pdo->prepare("
        SELECT ta.*, s.staff_no, s.name, s.position, d.name as dept_name, d.company
        FROM training_attendances ta
        JOIN staff s ON ta.staff_id = s.id
        LEFT JOIN departments d ON s.department_id = d.id
        ORDER BY d.name, s.name
    ");
    $stmt->execute();
    $attendees = $stmt->fetchAll();
}

// ── DEPT-DETAIL view ────────────────────────────────────────────────────
if ($view === 'dept_detail' && $dept_filter) {
    $deptInfo = $pdo->prepare("SELECT * FROM departments WHERE id = ?");
    $deptInfo->execute([$dept_filter]);
    $deptInfo = $deptInfo->fetch();

    $stmt = $pdo->prepare("
        SELECT s.staff_no, s.name, s.position,
               GROUP_CONCAT(CONCAT(tc.code,'|',tc.id,'|',COALESCE(ta.training_type,'External'))
                            ORDER BY tc.code SEPARATOR ';;;') AS trainings_raw
        FROM staff s
        LEFT JOIN training_attendances ta ON ta.staff_id = s.id
        LEFT JOIN training_courses tc ON ta.course_id = tc.id
        WHERE s.department_id = ?
        GROUP BY s.id ORDER BY s.name
    ");
    $stmt->execute([$dept_filter]);
    $dept_staff = $stmt->fetchAll();

    $stmt2 = $pdo->prepare("
        SELECT DISTINCT tc.*,
               COUNT(DISTINCT ta.staff_id)           AS attendee_count,
               COALESCE(tc.training_type,'External')  AS training_type
        FROM training_courses tc
        JOIN training_attendances ta ON ta.course_id = tc.id
        JOIN staff s ON ta.staff_id = s.id
        WHERE s.department_id = ?
        GROUP BY tc.id ORDER BY tc.code
    ");
    $stmt2->execute([$dept_filter]);
    $dept_courses = $stmt2->fetchAll();
}

// ── LIST view ───────────────────────────────────────────────────────────
if ($view === 'list') {
    $conds = []; $params = [];

    if (!isAdmin()) {
        $conds[] = 'ta.staff_id = (SELECT id FROM staff WHERE staff_no = ?)';
        $params[] = $user['staff_no'];
    } elseif ($dept_filter) {
        $conds[] = 's.department_id = ?'; $params[] = $dept_filter;
    }

    if ($company_f)   { $conds[] = 's.company = ?';  $params[] = $company_f; }
    if ($type_filter) { $conds[] = 'ta.training_type = ?'; $params[] = $type_filter; }
    if ($search) {
        $conds[] = '(s.name LIKE ? OR s.staff_no LIKE ? OR tc.code LIKE ? OR tc.title LIKE ?)';
        $like = "%$search%";
        array_push($params, $like, $like, $like, $like);
    }
    if ($status_f) { $conds[] = 'ta.status = ?'; $params[] = $status_f; }

    $where = $conds ? 'WHERE '.implode(' AND ',$conds) : '';

    $stmt = $pdo->prepare("
        SELECT ta.*, s.staff_no, s.name AS emp_name, s.position,
               d.name AS dept_name, d.company,
               tc.code AS training_code, tc.title AS training_title,
               COALESCE(ta.training_type, tc.training_type, 'External') AS training_type
        FROM training_attendances ta
        JOIN staff s  ON ta.staff_id  = s.id
        LEFT JOIN departments d  ON s.department_id = d.id
        JOIN training_courses tc ON ta.course_id = tc.id
        $where
        ORDER BY d.name, s.name, tc.code
    ");
    $stmt->execute($params);
    $records = $stmt->fetchAll();

    // per-type totals for this filtered set
    $extCount = count(array_filter($records, fn($r) => ($r['training_type'] ?? 'External') === 'External'));
    $intCount = count($records) - $extCount;
}
?>

<!-- ── Summary Bar ──────────────────────────────────────────────────── -->
<div class="training-summary-bar">
    <div class="tsb-item tsb-total">
        <span class="tsb-val"><?= number_format($typeTotals['grand_total']) ?></span>
        <span class="tsb-lbl">Total Trainings</span>
    </div>
    <div class="tsb-divider"></div>
    <div class="tsb-item tsb-ext">
        <span class="tsb-badge ext-badge">External</span>
        <span class="tsb-val"><?= number_format($typeTotals['ext_total']) ?></span>
        <span class="tsb-lbl">Attendances</span>
    </div>
    <div class="tsb-divider"></div>
    <div class="tsb-item tsb-int">
        <span class="tsb-badge int-badge">Internal</span>
        <span class="tsb-val"><?= number_format($typeTotals['int_total']) ?></span>
        <span class="tsb-lbl">Attendances</span>
    </div>
    <div class="tsb-divider"></div>
    <div class="tsb-item">
        <span class="tsb-val"><?= number_format($typeTotals['unique_staff']) ?></span>
        <span class="tsb-lbl">Unique Staff</span>
    </div>
    <div class="tsb-divider"></div>
    <div class="tsb-item">
        <span class="tsb-val"><?= number_format($typeTotals['unique_courses']) ?></span>
        <span class="tsb-lbl">Courses</span>
    </div>

    <!-- mini progress bar -->
    <?php
        $g = (int)$typeTotals['grand_total'] ?: 1;
        $ep = round($typeTotals['ext_total'] / $g * 100);
        $ip = 100 - $ep;
    ?>
    <div class="tsb-bar-wrap">
        <div class="tsb-bar-track">
            <div class="tsb-bar-ext" style="width:<?= $ep ?>%"></div>
            <div class="tsb-bar-int" style="width:<?= $ip ?>%"></div>
        </div>
        <div class="tsb-bar-legend">
            <span class="ext-dot">⬤</span> <?= $ep ?>% Ext &nbsp;
            <span class="int-dot">⬤</span> <?= $ip ?>% Int
        </div>
    </div>
</div>

<!-- ── Page Header ──────────────────────────────────────────────────── -->
<div class="page-header">
    <div>
        <h2><?= isAdmin() ? 'Training Records' : 'My Training Records' ?></h2>
        <p class="page-subtitle"><?= isAdmin() ? 'Training attendance by department and course' : 'Your personal training history' ?></p>
    </div>
    <?php if (isAdmin()): ?>
    <div style="display:flex;gap:.5rem;">
        <a href="?page=import_training" class="btn btn-outline btn-sm">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:4px;vertical-align:middle;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
            Import CSV
        </a>
        <button class="btn btn-outline btn-sm" onclick="openModal('addCourseModal')">+ Course</button>
        <button class="btn btn-primary btn-sm" onclick="openModal('addAttendanceModal')">+ Attendance</button>
    </div>
    <?php endif; ?>
</div>

<!-- ── Filter / Tab Bar ──────────────────────────────────────────────── -->
<div class="filter-bar" style="flex-wrap:wrap;gap:.5rem;align-items:center;">
    <?php if (isAdmin()): ?>
    <div class="filter-tabs">
        <a href="?page=training&view=by_dept<?= $dept_filter?"&dept=$dept_filter":'' ?><?= $type_filter?"&type=$type_filter":'' ?>" class="filter-tab <?= $view==='by_dept'?'active':'' ?>">📊 By Department</a>
        <a href="?page=training&view=list<?= $type_filter?"&type=$type_filter":'' ?>"  class="filter-tab <?= $view==='list'?'active':'' ?>">📋 List View</a>
        <a href="?page=training&view=courses"  class="filter-tab <?= $view==='courses'?'active':'' ?>">📚 Courses</a>
    </div>
    <?php endif; ?>

    <!-- ── Type toggle pills ── -->
    <div class="type-toggle-group">
        <a href="?page=training&view=<?= $view ?><?= $dept_filter?"&dept=$dept_filter":'' ?>&type="
           class="type-pill <?= $type_filter===''?'active':'' ?>">All</a>
        <a href="?page=training&view=<?= $view ?><?= $dept_filter?"&dept=$dept_filter":'' ?>&type=External"
           class="type-pill ext-pill <?= $type_filter==='External'?'active':'' ?>">External</a>
        <a href="?page=training&view=<?= $view ?><?= $dept_filter?"&dept=$dept_filter":'' ?>&type=Internal"
           class="type-pill int-pill <?= $type_filter==='Internal'?'active':'' ?>">Internal</a>
    </div>

    <!-- ── Live-search + other filters (list view only) ── -->
    <?php if ($view === 'list'): ?>
    <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-left:auto;align-items:center;" id="listFilters">
        <!-- LIVE SEARCH -->
        <div style="position:relative;">
            <input type="text" id="liveSearch" value="<?= htmlspecialchars($search) ?>"
                   placeholder="🔍  Search name, staff no, course…"
                   class="filter-search" style="width:230px;padding-right:28px;"
                   oninput="handleLiveSearch(this.value)">
            <span id="searchClear" onclick="clearSearch()"
                  style="display:<?= $search?'flex':'none' ?>;position:absolute;right:8px;top:50%;transform:translateY(-50%);cursor:pointer;color:#94a3b8;font-size:1rem;align-items:center;">✕</span>
        </div>

        <?php if (isAdmin()): ?>
        <select id="companyFilter" class="filter-select" onchange="applyFilters()">
            <option value="">All Companies</option>
            <option value="FJB"  <?= $company_f==='FJB' ?'selected':'' ?>>FJB</option>
            <option value="FBSB" <?= $company_f==='FBSB'?'selected':'' ?>>FBSB</option>
        </select>
        <select id="deptFilter" class="filter-select" onchange="applyFilters()">
            <option value="">All Depts</option>
            <?php foreach($allDepts as $d): ?>
            <option value="<?= $d['id'] ?>" <?= $dept_filter==$d['id']?'selected':'' ?>>[<?= $d['company'] ?>] <?= htmlspecialchars(substr($d['name'],0,28)) ?></option>
            <?php endforeach; ?>
        </select>
        <?php endif; ?>

        <select id="statusFilter" class="filter-select" onchange="applyFilters()">
            <option value="">All Status</option>
            <option value="Completed"   <?= $status_f==='Completed'  ?'selected':'' ?>>Completed</option>
            <option value="In Progress" <?= $status_f==='In Progress'?'selected':'' ?>>In Progress</option>
            <option value="Scheduled"   <?= $status_f==='Scheduled'  ?'selected':'' ?>>Scheduled</option>
        </select>

        <a href="?page=training&view=list" class="btn btn-ghost btn-sm">Clear</a>
    </div>
    <?php endif; ?>
</div>

<!-- ══════════════════════════════════════════════════════════════════════
     BY-DEPT VIEW
 ═══════════════════════════════════════════════════════════════════════ -->
<?php if ($view === 'by_dept'): ?>
<div class="dept-grid">
<?php foreach ($dept_summaries as $dept): ?>
<div class="dept-training-card">
    <div class="dept-card-header">
        <div>
            <span class="company-badge company-<?= strtolower($dept['company']) ?>"><?= $dept['company'] ?></span>
            <h4><?= htmlspecialchars($dept['name']) ?></h4>
        </div>
        <a href="?page=training&view=dept_detail&dept=<?= $dept['id'] ?>" class="btn btn-sm btn-outline">View →</a>
    </div>
    <div class="dept-card-stats">
        <div class="dstat"><span class="dstat-val"><?= $dept['staff_count'] ?></span><span class="dstat-lbl">Staff</span></div>
        <div class="dstat"><span class="dstat-val"><?= $dept['training_count'] ?></span><span class="dstat-lbl">Total</span></div>
        <div class="dstat ext-stat"><span class="dstat-val"><?= $dept['ext_count'] ?></span><span class="dstat-lbl">Ext</span></div>
        <div class="dstat int-stat"><span class="dstat-val"><?= $dept['int_count'] ?></span><span class="dstat-lbl">Int</span></div>
    </div>
    <!-- mini bar -->
    <?php
        $dt = max((int)$dept['training_count'], 1);
        $ep = round((int)$dept['ext_count'] / $dt * 100);
    ?>
    <div class="dept-type-bar">
        <div class="dept-type-fill-ext" style="width:<?= $ep ?>%"></div>
    </div>
</div>
<?php endforeach; ?>
</div>

<!-- ══════════════════════════════════════════════════════════════════════
     DEPT-DETAIL VIEW
 ═══════════════════════════════════════════════════════════════════════ -->
<?php elseif ($view === 'dept_detail' && $dept_filter): ?>
<div style="margin-bottom:1rem;"><a href="?page=training&view=by_dept" class="btn btn-ghost btn-sm">← Back to Departments</a></div>
<?php if ($deptInfo): ?>
<h3 style="margin-bottom:1rem;">
    <?= htmlspecialchars($deptInfo['name']) ?>
    <span class="company-badge company-<?= strtolower($deptInfo['company']) ?>"><?= $deptInfo['company'] ?></span>
</h3>

<?php if (!empty($dept_courses)): ?>
<div class="card" style="margin-bottom:1.5rem;">
    <div class="card-header"><h3>Courses Attended</h3></div>
    <table class="table">
        <thead><tr><th>Code</th><th>Type</th><th>Training Title</th><th>Attendees</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($dept_courses as $c): ?>
        <tr>
            <td><code class="training-code"><?= htmlspecialchars($c['code']) ?></code></td>
            <td><span class="type-badge type-<?= strtolower($c['training_type']) ?>"><?= $c['training_type'] ?></span></td>
            <td><?= htmlspecialchars($c['title']) ?></td>
            <td><span class="badge-count" style="position:static;display:inline-block;"><?= $c['attendee_count'] ?></span></td>
            <td><a href="?page=training&view=course&course_id=<?= $c['id'] ?>" class="btn btn-sm btn-ghost">Attendees</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div class="card">
    <div class="card-header"><h3>Staff Training Attendance</h3></div>
    <table class="table">
        <thead><tr><th>Staff No</th><th>Name</th><th>Position</th><th>Training Codes</th></tr></thead>
        <tbody>
        <?php foreach ($dept_staff as $s): ?>
        <tr>
            <td><code style="font-size:.82rem;color:#6366f1;"><?= htmlspecialchars($s['staff_no']) ?></code></td>
            <td><strong><?= htmlspecialchars($s['name']) ?></strong></td>
            <td style="font-size:.83rem;color:#64748b;"><?= htmlspecialchars($s['position']) ?></td>
            <td>
                <?php if ($s['trainings_raw']): ?>
                <?php foreach (explode(';;;', $s['trainings_raw']) as $t): ?>
                    <?php [$code, $cid, $ttype] = array_pad(explode('|', $t), 3, 'External'); ?>
                    <a href="?page=training&view=course&course_id=<?= $cid ?>"
                       class="training-code-tag tct-<?= strtolower($ttype) ?>"
                       title="<?= $ttype ?>"><?= htmlspecialchars($code) ?></a>
                <?php endforeach; ?>
                <?php else: ?><span style="color:#94a3b8;font-size:.82rem;">No training</span><?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════════════════
     COURSE-ATTENDEES VIEW
 ═══════════════════════════════════════════════════════════════════════ -->
<?php elseif ($view === 'course' && $course_id): ?>
<div style="margin-bottom:1rem;"><a href="?page=training&view=by_dept" class="btn btn-ghost btn-sm">← Back</a></div>
<?php if ($course): ?>
<div class="card" style="margin-bottom:1rem;padding:1.25rem;">
    <div style="display:flex;gap:1rem;align-items:flex-start;">
        <div style="background:#6366f1;color:white;padding:.5rem .9rem;border-radius:8px;font-weight:700;font-size:1.1rem;"><?= htmlspecialchars($course['code']) ?></div>
        <div>
            <h3 style="margin:0 0 .25rem;"><?= htmlspecialchars($course['title']) ?></h3>
            <?php $tt = $course['training_type'] ?? 'External'; ?>
            <span class="type-badge type-<?= strtolower($tt) ?>"><?= $tt ?></span>
            <span style="color:#64748b;font-size:.85rem;margin-left:.5rem;"><?= count($attendees) ?> attendee(s)</span>
        </div>
    </div>
</div>
<div class="card">
    <table class="table">
        <thead><tr><th>Staff No</th><th>Name</th><th>Dept</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($attendees as $a): ?>
        <tr>
            <td><code style="font-size:.82rem;color:#6366f1;"><?= htmlspecialchars($a['staff_no']) ?></code></td>
            <td><strong><?= htmlspecialchars($a['name']) ?></strong></td>
            <td><span class="dept-badge"><?= htmlspecialchars($a['dept_name']??'—') ?></span></td>
            <td><span class="status-badge status-<?= strtolower(str_replace(' ','-',$a['status'])) ?>"><?= $a['status'] ?></span></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════════════════
     COURSES VIEW
 ═══════════════════════════════════════════════════════════════════════ -->
<?php elseif ($view === 'courses'): ?>
<div class="card">
    <div class="card-header">
        <h3>All Training Courses (<?= count($allCourses) ?>)</h3>
        <input type="text" id="courseSearch" placeholder="Search courses…" class="filter-search"
               oninput="filterCourses(this.value)" style="width:220px;">
    </div>
    <table class="table" id="courseTable">
        <thead><tr><th>Code</th><th>Type</th><th>Training Title</th><th>Attendees</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($allCourses as $c):
            $cnt = $pdo->prepare("SELECT COUNT(*) FROM training_attendances WHERE course_id = ?");
            $cnt->execute([$c['id']]); $n = $cnt->fetchColumn();
            $tt  = $c['training_type'] ?? 'External';
        ?>
        <tr class="course-row">
            <td><code class="training-code"><?= htmlspecialchars($c['code']) ?></code></td>
            <td><span class="type-badge type-<?= strtolower($tt) ?>"><?= $tt ?></span></td>
            <td><?= htmlspecialchars($c['title']) ?></td>
            <td><?= $n ?></td>
            <td><a href="?page=training&view=course&course_id=<?= $c['id'] ?>" class="btn btn-sm btn-ghost">Attendees</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- ══════════════════════════════════════════════════════════════════════
     LIST VIEW
 ═══════════════════════════════════════════════════════════════════════ -->
<?php elseif ($view === 'list'): ?>

<!-- Result count bar -->
<div class="result-count-bar" id="resultCountBar">
    <span id="resultCount"><?= count($records) ?></span> record(s)
    <?php if ($type_filter): ?>
        &nbsp;·&nbsp; <span class="type-badge type-<?= strtolower($type_filter) ?>"><?= $type_filter ?></span>
    <?php endif; ?>
    <?php if (!empty($records)): ?>
    <span style="margin-left:.75rem;font-size:.78rem;color:#94a3b8;">
        &nbsp;·&nbsp; <span class="ext-col"><?= $extCount ?> External</span>
        &nbsp;/&nbsp; <span class="int-col"><?= $intCount ?> Internal</span>
    </span>
    <?php endif; ?>
</div>

<div class="card">
    <?php if (empty($records)): ?>
    <div class="empty-state"><p>No training records found.</p></div>
    <?php else: ?>
    <table class="table" id="trainingListTable">
        <thead>
            <tr>
                <?php if (isAdmin()): ?><th>Staff No</th><th>Name</th><th>Dept</th><?php endif; ?>
                <th>Code</th><th>Type</th><th>Training Title</th><th>Status</th><th>Actions</th>
            </tr>
        </thead>
        <tbody id="trainingListBody">
        <?php foreach ($records as $r):
            $tt = $r['training_type'] ?? 'External';
        ?>
        <tr data-search="<?= strtolower(htmlspecialchars(($r['staff_no']??'').' '.($r['emp_name']??'').' '.$r['training_code'].' '.$r['training_title'])) ?>"
            data-type="<?= $tt ?>">
            <?php if (isAdmin()): ?>
            <td><code style="font-size:.82rem;color:#6366f1;"><?= htmlspecialchars($r['staff_no']) ?></code></td>
            <td><?= htmlspecialchars($r['emp_name']) ?></td>
            <td><span class="dept-badge"><?= htmlspecialchars($r['dept_name']??'—') ?></span></td>
            <?php endif; ?>
            <td><code class="training-code"><?= htmlspecialchars($r['training_code']) ?></code></td>
            <td><span class="type-badge type-<?= strtolower($tt) ?>"><?= $tt ?></span></td>
            <td style="max-width:280px;font-size:.85rem;"><?= htmlspecialchars($r['training_title']) ?></td>
            <td><span class="status-badge status-<?= strtolower(str_replace(' ','-',$r['status'])) ?>"><?= $r['status'] ?></span></td>
            <td class="td-actions">
                <?php if (isAdmin()): ?>
                <button class="btn btn-sm btn-outline" onclick="editAttendance(<?= htmlspecialchars(json_encode($r)) ?>)">Edit</button>
                <button class="btn btn-sm btn-danger"  onclick="confirmDeleteAtt(<?= $r['id'] ?>)">Delete</button>
                <?php else: ?>
                <button class="btn btn-sm btn-ghost" onclick="openRequestModal(<?= $r['id'] ?>,'<?= htmlspecialchars(addslashes($r['training_code'])) ?>')">Request Update</button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
<?php endif; ?>

<!-- ══════════════════════════════════════════════════════════════════════
     MODALS
 ═══════════════════════════════════════════════════════════════════════ -->
<?php if (isAdmin()): ?>
<div class="modal" id="addCourseModal">
    <div class="modal-box">
        <div class="modal-header"><h3>Add Training Course</h3><button class="modal-close" onclick="closeModal()">×</button></div>
        <form method="POST" action="actions/training.php">
            <input type="hidden" name="action" value="add_course">
            <div class="form-grid">
                <div class="form-group"><label>Course Code *</label><input type="text" name="code" required></div>
                <div class="form-group">
                    <label>Type *</label>
                    <select name="training_type">
                        <option value="External">External</option>
                        <option value="Internal">Internal</option>
                    </select>
                </div>
                <div class="form-group"><label>Company</label>
                    <select name="company"><option value="FJB">FJB</option><option value="FBSB">FBSB</option></select>
                </div>
                <div class="form-group form-full"><label>Training Title *</label><input type="text" name="title" required></div>
                <div class="form-group"><label>Training Date</label><input type="date" name="training_date"></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button><button type="submit" class="btn btn-primary">Save Course</button></div>
        </form>
    </div>
</div>

<div class="modal" id="addAttendanceModal">
    <div class="modal-box">
        <div class="modal-header"><h3 id="attModalTitle">Add Training Attendance</h3><button class="modal-close" onclick="closeModal()">×</button></div>
        <form method="POST" action="actions/training.php">
            <input type="hidden" name="action" id="attAction" value="add_attendance">
            <input type="hidden" name="id"     id="attId"     value="">
            <div class="form-grid">
                <div class="form-group form-full">
                    <label>Staff No / Name *</label>
                    <input type="text" name="staff_search" id="staffSearchInput" placeholder="Type to search…" oninput="searchStaff(this.value)" autocomplete="off">
                    <input type="hidden" name="staff_id" id="selectedStaffId">
                    <div id="staffDropdown" style="display:none;border:1px solid #e2e8f0;border-radius:8px;max-height:200px;overflow-y:auto;margin-top:4px;background:white;position:relative;z-index:100;"></div>
                </div>
                <div class="form-group form-full">
                    <label>Training Course *</label>
                    <select name="course_id" id="f_course_id" required>
                        <option value="">Select Course</option>
                        <?php foreach ($allCourses as $c): ?>
                        <option value="<?= $c['id'] ?>">[<?= $c['training_type']??'Ext' ?>] <?= htmlspecialchars($c['code']) ?> — <?= htmlspecialchars(substr($c['title'],0,55)) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group"><label>Status</label>
                    <select name="status" id="f_att_status">
                        <option value="Completed">Completed</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Scheduled">Scheduled</option>
                    </select>
                </div>
                <div class="form-group form-full"><label>Remarks</label><textarea name="remarks" id="f_att_remarks" rows="2"></textarea></div>
            </div>
            <div class="modal-footer"><button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button><button type="submit" class="btn btn-primary">Save</button></div>
        </form>
    </div>
</div>

<div class="modal" id="deleteAttModal">
    <div class="modal-box modal-sm">
        <div class="modal-header"><h3>Confirm Delete</h3><button class="modal-close" onclick="closeModal()">×</button></div>
        <p style="padding:1rem 0;">Delete this attendance record?</p>
        <form method="POST" action="actions/training.php">
            <input type="hidden" name="action" value="delete_attendance">
            <input type="hidden" name="id" id="deleteAttId" value="">
            <div class="modal-footer"><button type="submit" class="btn btn-danger">Delete</button></div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="modal" id="requestModal">
    <div class="modal-box modal-sm">
        <div class="modal-header"><h3>Request Update</h3><button class="modal-close" onclick="closeModal()">×</button></div>
        <form method="POST" action="actions/request.php">
            <input type="hidden" name="record_type" value="Training Record">
            <input type="hidden" name="record_id"   id="reqRecordId"  value="">
            <input type="hidden" name="record_reference" id="reqRecordRef" value="">
            <div class="form-group"><label>Your Message *</label><textarea name="message" rows="4" placeholder="Describe what needs to be updated…" required></textarea></div>
            <div class="modal-footer"><button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button><button type="submit" class="btn btn-primary">Send</button></div>
        </form>
    </div>
</div>

<!-- ══════════════════════════════════════════════════════════════════════
     JAVASCRIPT
 ═══════════════════════════════════════════════════════════════════════ -->
<script>
// ── Live search (client-side instant filter) ──────────────────────────
let liveSearchTimer;

function handleLiveSearch(val) {
    clearTimeout(liveSearchTimer);
    document.getElementById('searchClear').style.display = val ? 'flex' : 'none';

    // Instant client-side filter on the current table rows
    filterTableRows(val.toLowerCase());

    // Debounce server reload for full-text across DB
    liveSearchTimer = setTimeout(() => {
        if (val.length === 0 || val.length >= 2) applyFilters();
    }, 500);
}

function filterTableRows(q) {
    const body = document.getElementById('trainingListBody');
    if (!body) return;

    const rows = body.querySelectorAll('tr');
    let vis = 0;
    const typeFilter = '<?= $type_filter ?>';

    rows.forEach(row => {
        const text  = row.dataset.search || '';
        const rtype = row.dataset.type   || '';
        const matchQ    = !q      || text.includes(q);
        const matchType = !typeFilter || rtype === typeFilter;
        const show = matchQ && matchType;
        row.style.display = show ? '' : 'none';
        if (show) vis++;
    });

    const rc = document.getElementById('resultCount');
    if (rc) rc.textContent = vis;
}

function clearSearch() {
    document.getElementById('liveSearch').value = '';
    document.getElementById('searchClear').style.display = 'none';
    filterTableRows('');
    applyFilters();
}

// ── Server-side filter reload ─────────────────────────────────────────
function applyFilters() {
    const q       = document.getElementById('liveSearch')?.value || '';
    const company = document.getElementById('companyFilter')?.value || '';
    const dept    = document.getElementById('deptFilter')?.value || '';
    const status  = document.getElementById('statusFilter')?.value || '';
    const type    = '<?= $type_filter ?>';

    const params = new URLSearchParams({ page: 'training', view: 'list' });
    if (q)       params.set('q', q);
    if (company) params.set('company', company);
    if (dept)    params.set('dept', dept);
    if (status)  params.set('status', status);
    if (type)    params.set('type', type);

    window.location.href = '?' + params.toString();
}

// ── Courses filter ────────────────────────────────────────────────────
function filterCourses(q) {
    document.querySelectorAll('.course-row').forEach(r => {
        r.style.display = r.textContent.toLowerCase().includes(q.toLowerCase()) ? '' : 'none';
    });
}

// ── Edit / Delete attendance ──────────────────────────────────────────
function editAttendance(data) {
    document.getElementById('attModalTitle').textContent = 'Edit Attendance';
    document.getElementById('attAction').value  = 'edit_attendance';
    document.getElementById('attId').value      = data.id;
    document.getElementById('f_course_id').value = data.course_id;
    document.getElementById('f_att_status').value = data.status;
    document.getElementById('f_att_remarks').value = data.remarks || '';
    openModal('addAttendanceModal');
}
function confirmDeleteAtt(id) { document.getElementById('deleteAttId').value = id; openModal('deleteAttModal'); }
function openRequestModal(id, ref) {
    document.getElementById('reqRecordId').value  = id;
    document.getElementById('reqRecordRef').value = ref;
    openModal('requestModal');
}

// ── Staff search autocomplete ─────────────────────────────────────────
let staffTimeout;
function searchStaff(q) {
    clearTimeout(staffTimeout);
    const dd = document.getElementById('staffDropdown');
    if (q.length < 2) { dd.style.display = 'none'; return; }
    staffTimeout = setTimeout(() => {
        fetch('actions/training.php?search_staff=' + encodeURIComponent(q))
            .then(r => r.json())
            .then(data => {
                if (!data.length) { dd.style.display = 'none'; return; }
                dd.innerHTML = data.map(s =>
                    `<div onclick="selectStaff(${s.id},'${s.staff_no} - ${s.name.replace(/'/g,"\\'")}','${s.name.replace(/'/g,"\\'")} (${s.staff_no})')"
                          style="padding:.5rem .75rem;cursor:pointer;font-size:.9rem;border-bottom:1px solid #f1f5f9;"
                          onmouseover="this.style.background='#f8fafc'" onmouseout="this.style.background='white'">
                        <strong>${s.staff_no}</strong> — ${s.name}
                        <span style="color:#94a3b8;font-size:.8rem;">${s.dept_name||''}</span>
                    </div>`
                ).join('');
                dd.style.display = 'block';
            });
    }, 300);
}
function selectStaff(id, displayVal) {
    document.getElementById('selectedStaffId').value = id;
    document.getElementById('staffSearchInput').value = displayVal;
    document.getElementById('staffDropdown').style.display = 'none';
}
</script>

<style>
/* ── Summary Bar ────────────────────────────────────────────────── */
.training-summary-bar {
    display: flex;
    align-items: center;
    gap: 0;
    background: #fff;
    border: 1px solid var(--border);
    border-radius: 12px;
    padding: .75rem 1.25rem;
    margin-bottom: 1.25rem;
    flex-wrap: wrap;
    gap: .25rem;
    box-shadow: var(--shadow);
}
.tsb-item { display:flex; flex-direction:column; align-items:center; padding: .25rem .9rem; min-width: 80px; }
.tsb-val  { font-size: 1.5rem; font-weight: 700; color: var(--text); line-height:1.1; }
.tsb-lbl  { font-size: .7rem; color: var(--muted); font-weight: 600; text-transform: uppercase; letter-spacing:.04em; margin-top:.15rem; }
.tsb-divider { width:1px; height:40px; background:var(--border); margin:0 .25rem; }
.tsb-badge { padding:.2rem .65rem; border-radius:20px; font-size:.72rem; font-weight:700; margin-bottom:.2rem; }
.ext-badge { background:#fff7ed; color:#c2410c; border:1px solid #fed7aa; }
.int-badge { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; }
.tsb-bar-wrap { margin-left: auto; display:flex; flex-direction:column; align-items:flex-end; gap:.3rem; padding-left:.75rem; }
.tsb-bar-track { display:flex; width:140px; height:8px; border-radius:99px; overflow:hidden; background:var(--border); }
.tsb-bar-ext { background:#f97316; }
.tsb-bar-int { background:#22c55e; }
.tsb-bar-legend { font-size:.7rem; color:var(--muted); white-space:nowrap; }
.ext-dot { color:#f97316; }
.int-dot { color:#22c55e; }

/* ── Type toggle pills ──────────────────────────────────────────── */
.type-toggle-group { display:flex; gap:.25rem; background:#f8fafc; border:1px solid var(--border); border-radius:8px; padding:.2rem; }
.type-pill { padding:.28rem .85rem; border-radius:6px; font-size:.8rem; font-weight:600; color:var(--muted); transition:.15s; text-decoration:none; }
.type-pill:hover { background:#e2e8f0; color:var(--text); }
.type-pill.active { background:#fff; color:var(--text); box-shadow:0 1px 3px rgba(0,0,0,.1); }
.ext-pill.active { background:#fff7ed; color:#c2410c; }
.int-pill.active { background:#f0fdf4; color:#15803d; }

/* ── Type badges (inline in table) ─────────────────────────────── */
.type-badge { display:inline-block; padding:.15rem .55rem; border-radius:20px; font-size:.72rem; font-weight:700; }
.type-external { background:#fff7ed; color:#c2410c; border:1px solid #fed7aa; }
.type-internal { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; }

/* ── Dept card ext/int stats ────────────────────────────────────── */
.ext-stat .dstat-val { color:#c2410c; }
.int-stat .dstat-val { color:#15803d; }
.dept-type-bar { height:4px; background:var(--border); border-radius:99px; margin-top:.75rem; overflow:hidden; display:flex; }
.dept-type-fill-ext { background:#f97316; height:100%; border-radius:99px; transition:width .5s; }

/* ── Training code tags coloured by type ────────────────────────── */
.tct-external { background:#fff7ed !important; color:#c2410c !important; border-color:#fed7aa !important; }
.tct-internal { background:#f0fdf4 !important; color:#15803d !important; border-color:#bbf7d0 !important; }

/* ── Result count bar ───────────────────────────────────────────── */
.result-count-bar { font-size:.82rem; color:var(--muted); padding:.4rem 0 .6rem; display:flex; align-items:center; gap:.25rem; }
.ext-col { color:#c2410c; font-weight:600; }
.int-col { color:#15803d; font-weight:600; }
</style>
