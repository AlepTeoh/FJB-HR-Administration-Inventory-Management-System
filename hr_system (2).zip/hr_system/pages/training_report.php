<?php
// pages/training_report.php  — v3: Monthly chart + External/Internal breakdown
require_once __DIR__ . '/../includes/config.php';
$pdo  = getDB();
$user = currentUser();

// ── Filters ────────────────────────────────────────────────────────────
$dept_id     = $_GET['dept']    ?? '';
$month_f     = $_GET['month']   ?? '';
$year_f      = $_GET['year']    ?? date('Y');
$type_filter = $_GET['type']    ?? '';   // External | Internal | ''
$company_f   = $_GET['company'] ?? '';

$departments = $pdo->query("SELECT id, name, company FROM departments ORDER BY company, name")->fetchAll();

// ── Base WHERE builder ─────────────────────────────────────────────────
function buildWhere(array $extra = [], array &$params = []) {
    $c = $extra;
    return $c ? 'WHERE ' . implode(' AND ', $c) : '';
}

$conds  = [];
$params = [];

if ($year_f)      { $conds[] = 'YEAR(tc.training_date) = ?';   $params[] = $year_f; }
if ($dept_id)     { $conds[] = 's.department_id = ?';          $params[] = $dept_id; }
if ($month_f)     { $conds[] = 'MONTH(tc.training_date) = ?';  $params[] = $month_f; }
if ($type_filter) { $conds[] = 'COALESCE(ta.training_type, tc.training_type, \'External\') = ?'; $params[] = $type_filter; }
if ($company_f)   { $conds[] = 'd.company = ?';                $params[] = $company_f; }

$where_sql = $conds ? 'WHERE ' . implode(' AND ', $conds) : '';

// ── Main data ──────────────────────────────────────────────────────────
$sql = "
    SELECT ta.*,
           s.staff_no, s.name AS staff_name, s.position,
           d.name AS dept_name, d.company,
           tc.code AS course_code, tc.title AS course_title,
           tc.training_date,
           COALESCE(ta.training_type, tc.training_type, 'External') AS training_type
    FROM training_attendances ta
    JOIN staff s              ON ta.staff_id  = s.id
    JOIN training_courses tc  ON ta.course_id = tc.id
    LEFT JOIN departments d   ON s.department_id = d.id
    $where_sql
    ORDER BY tc.training_date DESC, d.name ASC
";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$reports = $stmt->fetchAll();

$total_attendees  = count($reports);
$unique_courses   = count(array_unique(array_column($reports, 'course_id')));
$unique_staff     = count(array_unique(array_column($reports, 'staff_no')));
$ext_count        = count(array_filter($reports, fn($r) => $r['training_type'] === 'External'));
$int_count        = $total_attendees - $ext_count;

// ── Monthly breakdown (for selected year, respecting dept/type filters) ─
$monthConds  = [];
$monthParams = [];
$monthConds[] = 'YEAR(tc.training_date) = ?'; $monthParams[] = $year_f;
if ($dept_id)     { $monthConds[] = 's.department_id = ?'; $monthParams[] = $dept_id; }
if ($type_filter) { $monthConds[] = 'COALESCE(ta.training_type, tc.training_type, \'External\') = ?'; $monthParams[] = $type_filter; }
if ($company_f)   { $monthConds[] = 'd.company = ?'; $monthParams[] = $company_f; }
$monthWhere = 'WHERE ' . implode(' AND ', $monthConds);

$monthlyStmt = $pdo->prepare("
    SELECT
        MONTH(tc.training_date)                                        AS mon,
        COUNT(*)                                                       AS total,
        SUM(COALESCE(ta.training_type, tc.training_type,'External') = 'External') AS ext_cnt,
        SUM(COALESCE(ta.training_type, tc.training_type,'External') = 'Internal') AS int_cnt,
        COUNT(DISTINCT ta.staff_id)                                    AS unique_staff,
        COUNT(DISTINCT ta.course_id)                                   AS unique_courses
    FROM training_attendances ta
    JOIN training_courses tc  ON ta.course_id = tc.id
    JOIN staff s              ON ta.staff_id  = s.id
    LEFT JOIN departments d   ON s.department_id = d.id
    $monthWhere
    GROUP BY MONTH(tc.training_date)
    ORDER BY mon
");
$monthlyStmt->execute($monthParams);
$monthlyRaw = $monthlyStmt->fetchAll();

// Fill all 12 months
$monthlyData = array_fill(1, 12, ['total'=>0,'ext_cnt'=>0,'int_cnt'=>0,'unique_staff'=>0,'unique_courses'=>0]);
foreach ($monthlyRaw as $row) { $monthlyData[(int)$row['mon']] = $row; }
$maxMonthVal = max(array_column($monthlyData,'total') ?: [1]);
$maxMonthVal = max($maxMonthVal, 1);

$monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

// ── Top courses ────────────────────────────────────────────────────────
$topCoursesConds  = $conds;
$topCoursesParams = $params;
$topCoursesWhere  = $where_sql;

$topCoursesStmt = $pdo->prepare("
    SELECT tc.code, tc.title,
           COALESCE(tc.training_type,'External') AS training_type,
           COUNT(*) AS cnt
    FROM training_attendances ta
    JOIN training_courses tc ON ta.course_id = tc.id
    JOIN staff s ON ta.staff_id = s.id
    LEFT JOIN departments d ON s.department_id = d.id
    $topCoursesWhere
    GROUP BY tc.id ORDER BY cnt DESC LIMIT 8
");
$topCoursesStmt->execute($topCoursesParams);
$topCourses = $topCoursesStmt->fetchAll();
$maxCourse  = max(array_column($topCourses,'cnt') ?: [1]);
?>

<div class="page-header">
    <div>
        <h2>Training Report</h2>
        <p class="page-subtitle">Training attendance by month — <?= $year_f ?></p>
    </div>
    <div class="header-actions" style="display:flex;gap:.5rem;">
        <button class="btn btn-outline btn-sm" onclick="window.print()">
            <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="margin-right:5px;vertical-align:middle;"><path d="M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 14h12v8H6z"/></svg>
            Print
        </button>
    </div>
</div>

<!-- ── Filter Card ────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:1.25rem;">
    <form method="GET" style="display:flex;gap:.75rem;flex-wrap:wrap;align-items:flex-end;padding:1rem 1.25rem;">
        <input type="hidden" name="page" value="training_report">

        <div class="form-group" style="margin-bottom:0;">
            <label class="filter-label">Year</label>
            <select name="year" class="filter-select" onchange="this.form.submit()">
                <?php for ($y = date('Y'); $y >= 2022; $y--): ?>
                <option value="<?= $y ?>" <?= $year_f == $y ?'selected':'' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="filter-label">Month</label>
            <select name="month" class="filter-select">
                <option value="">All Months</option>
                <?php for ($m = 1; $m <= 12; $m++): ?>
                <option value="<?= $m ?>" <?= $month_f == $m ?'selected':'' ?>><?= date('F', mktime(0,0,0,$m,1)) ?></option>
                <?php endfor; ?>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="filter-label">Training Type</label>
            <select name="type" class="filter-select">
                <option value="">All Types</option>
                <option value="External" <?= $type_filter==='External'?'selected':'' ?>>External</option>
                <option value="Internal" <?= $type_filter==='Internal'?'selected':'' ?>>Internal</option>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="filter-label">Company</label>
            <select name="company" class="filter-select">
                <option value="">All Companies</option>
                <option value="FJB"  <?= $company_f==='FJB' ?'selected':'' ?>>FJB</option>
                <option value="FBSB" <?= $company_f==='FBSB'?'selected':'' ?>>FBSB</option>
            </select>
        </div>

        <div class="form-group" style="margin-bottom:0;">
            <label class="filter-label">Department</label>
            <select name="dept" class="filter-select" style="min-width:200px;">
                <option value="">All Departments</option>
                <?php foreach ($departments as $d): ?>
                <option value="<?= $d['id'] ?>" <?= $dept_id==$d['id']?'selected':'' ?>>
                    [<?= $d['company'] ?>] <?= htmlspecialchars($d['name']) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary btn-sm" style="height:38px;">Apply</button>
        <a href="?page=training_report" class="btn btn-ghost btn-sm" style="height:38px;line-height:38px;">Reset</a>
    </form>
</div>

<!-- ── KPI Cards ──────────────────────────────────────────────────────── -->
<div class="rpt-kpi-row">
    <div class="rpt-kpi">
        <div class="rpt-kpi-icon" style="background:#eff6ff;color:#2563eb;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>
        </div>
        <div>
            <div class="rpt-kpi-val"><?= number_format($total_attendees) ?></div>
            <div class="rpt-kpi-lbl">Total Attendances</div>
        </div>
    </div>
    <div class="rpt-kpi ext-kpi">
        <div class="rpt-kpi-icon" style="background:#fff7ed;color:#c2410c;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>
        </div>
        <div>
            <div class="rpt-kpi-val ext-val"><?= number_format($ext_count) ?></div>
            <div class="rpt-kpi-lbl">External Training</div>
        </div>
    </div>
    <div class="rpt-kpi int-kpi">
        <div class="rpt-kpi-icon" style="background:#f0fdf4;color:#15803d;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
        </div>
        <div>
            <div class="rpt-kpi-val int-val"><?= number_format($int_count) ?></div>
            <div class="rpt-kpi-lbl">Internal Training</div>
        </div>
    </div>
    <div class="rpt-kpi">
        <div class="rpt-kpi-icon" style="background:#faf5ff;color:#7c3aed;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        </div>
        <div>
            <div class="rpt-kpi-val"><?= number_format($unique_staff) ?></div>
            <div class="rpt-kpi-lbl">Unique Staff</div>
        </div>
    </div>
    <div class="rpt-kpi">
        <div class="rpt-kpi-icon" style="background:#f8fafc;color:#475569;">
            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
        </div>
        <div>
            <div class="rpt-kpi-val"><?= $month_f ? date('M', mktime(0,0,0,$month_f,1)) : 'Full Year' ?></div>
            <div class="rpt-kpi-lbl"><?= $year_f ?> <?= $type_filter ? "· $type_filter" : '' ?></div>
        </div>
    </div>
</div>

<!-- ── Monthly Chart ──────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:1.25rem;">
    <div class="card-header" style="align-items:center;">
        <h3 class="card-title">Training by Month — <?= $year_f ?></h3>
        <div style="display:flex;gap:.75rem;align-items:center;font-size:.78rem;">
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#f97316;margin-right:4px;"></span>External</span>
            <span><span style="display:inline-block;width:10px;height:10px;border-radius:3px;background:#22c55e;margin-right:4px;"></span>Internal</span>
        </div>
    </div>
    <div class="monthly-chart-wrap">
        <?php foreach ($monthlyData as $m => $md):
            $active = ($month_f == $m);
            $extH = $maxMonthVal > 0 ? round((int)$md['ext_cnt'] / $maxMonthVal * 100) : 0;
            $intH = $maxMonthVal > 0 ? round((int)$md['int_cnt'] / $maxMonthVal * 100) : 0;
            $href = '?page=training_report&year='.$year_f.'&month='.($month_f==$m?'':$m)
                   .($type_filter?"&type=$type_filter":'').($dept_id?"&dept=$dept_id":'')
                   .($company_f?"&company=$company_f":'');
        ?>
        <a href="<?= $href ?>" class="month-col <?= $active?'month-active':'' ?>" title="<?= date('F Y', mktime(0,0,0,$m,1,$year_f)) ?>: <?= $md['total'] ?> total">
            <div class="month-bars">
                <div class="month-bar-ext" style="height:<?= $extH ?>%" title="External: <?= $md['ext_cnt'] ?>"></div>
                <div class="month-bar-int" style="height:<?= $intH ?>%" title="Internal: <?= $md['int_cnt'] ?>"></div>
            </div>
            <div class="month-total"><?= $md['total'] ?: '' ?></div>
            <div class="month-name <?= $active?'month-name-active':'' ?>"><?= $monthNames[$m-1] ?></div>
            <?php if ($active): ?>
            <div class="month-detail-tip">
                <div class="mdt-row"><span class="mdt-ext">▐</span> Ext: <?= $md['ext_cnt'] ?></div>
                <div class="mdt-row"><span class="mdt-int">▐</span> Int: <?= $md['int_cnt'] ?></div>
                <div class="mdt-row" style="margin-top:2px;">👤 <?= $md['unique_staff'] ?> staff</div>
            </div>
            <?php endif; ?>
        </a>
        <?php endforeach; ?>
    </div>
</div>

<!-- ── Two-column: Top Courses + External/Internal breakdown ─────────── -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1.25rem;margin-bottom:1.25rem;">

    <!-- Top Courses -->
    <div class="card">
        <div class="card-header"><h3 class="card-title">Top Courses</h3></div>
        <div style="padding:.75rem 1.25rem;">
        <?php if (empty($topCourses)): ?>
            <p style="color:var(--muted);text-align:center;padding:1.5rem 0;font-size:.875rem;">No data for selected filters.</p>
        <?php else: ?>
            <?php foreach ($topCourses as $tc):
                $pct = round($tc['cnt'] / $maxCourse * 100);
                $isExt = $tc['training_type'] === 'External';
                $barColor = $isExt ? '#f97316' : '#22c55e';
            ?>
            <div style="margin-bottom:.8rem;">
                <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.3rem;">
                    <div style="font-size:.8rem;font-weight:600;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;" title="<?= htmlspecialchars($tc['title']) ?>">
                        <code class="training-code" style="font-size:.7rem;"><?= htmlspecialchars($tc['code']) ?></code>
                        <?= htmlspecialchars(substr($tc['title'],0,30)) ?>…
                    </div>
                    <div style="display:flex;gap:.4rem;align-items:center;flex-shrink:0;">
                        <span class="type-badge type-<?= strtolower($tc['training_type']) ?>"><?= $tc['training_type'] ?></span>
                        <strong style="font-size:.82rem;"><?= $tc['cnt'] ?></strong>
                    </div>
                </div>
                <div style="height:6px;background:var(--border);border-radius:99px;overflow:hidden;">
                    <div style="height:100%;width:<?= $pct ?>%;background:<?= $barColor ?>;border-radius:99px;transition:width .5s;"></div>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
        </div>
    </div>

    <!-- External vs Internal Breakdown -->
    <div class="card">
        <div class="card-header"><h3 class="card-title">External vs Internal</h3></div>
        <div style="padding:1.25rem;">
            <?php if ($total_attendees > 0):
                $ep = round($ext_count / $total_attendees * 100);
                $ip = 100 - $ep;
            ?>
            <!-- Donut-style summary -->
            <div class="type-split-bars">
                <div class="tsplit-item">
                    <div class="tsplit-label">
                        <span class="tsplit-dot ext-dot-sq"></span>External
                        <span class="tsplit-pct"><?= $ep ?>%</span>
                    </div>
                    <div class="tsplit-track">
                        <div class="tsplit-fill" style="width:<?= $ep ?>%;background:#f97316;"></div>
                    </div>
                    <div class="tsplit-count"><?= number_format($ext_count) ?></div>
                </div>
                <div class="tsplit-item">
                    <div class="tsplit-label">
                        <span class="tsplit-dot int-dot-sq"></span>Internal
                        <span class="tsplit-pct"><?= $ip ?>%</span>
                    </div>
                    <div class="tsplit-track">
                        <div class="tsplit-fill" style="width:<?= $ip ?>%;background:#22c55e;"></div>
                    </div>
                    <div class="tsplit-count"><?= number_format($int_count) ?></div>
                </div>
            </div>
            <!-- Combined bar -->
            <div style="margin-top:1.25rem;">
                <div style="font-size:.78rem;color:var(--muted);margin-bottom:.4rem;">Combined proportion</div>
                <div style="height:12px;background:var(--border);border-radius:99px;overflow:hidden;display:flex;">
                    <div style="width:<?= $ep ?>%;background:#f97316;"></div>
                    <div style="flex:1;background:#22c55e;"></div>
                </div>
            </div>
            <!-- Monthly quick-stats if filtered -->
            <?php if ($month_f): ?>
            <div style="margin-top:1.25rem;padding:1rem;background:#f8fafc;border-radius:8px;font-size:.8rem;">
                <strong><?= date('F', mktime(0,0,0,$month_f,1)) ?> <?= $year_f ?>:</strong><br>
                <span style="color:#c2410c;">External: <?= $ext_count ?></span> &nbsp;·&nbsp;
                <span style="color:#15803d;">Internal: <?= $int_count ?></span>
            </div>
            <?php endif; ?>
            <?php else: ?>
            <p style="color:var(--muted);text-align:center;padding:2rem 0;font-size:.875rem;">No data for selected filters.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- ── Detail Table ───────────────────────────────────────────────────── -->
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Training Records</h3>
        <div style="display:flex;gap:.5rem;align-items:center;">
            <span style="font-size:.8rem;color:var(--muted);"><?= $total_attendees ?> records</span>
            <input type="text" id="rptSearch" placeholder="🔍 Search…" class="filter-search"
                   oninput="filterRptTable(this.value)" style="width:180px;">
        </div>
    </div>
    <div class="table-responsive">
        <table class="table" id="rptTable">
            <thead>
                <tr>
                    <th>Date</th><th>Type</th><th>Course</th>
                    <th>Staff</th><th>Department</th><th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php if (empty($reports)): ?>
                <tr><td colspan="6" class="empty-state" style="text-align:center;padding:2rem;color:var(--muted);">No records for selected filters.</td></tr>
            <?php else: ?>
                <?php foreach ($reports as $r): ?>
                <tr class="rpt-row">
                    <td style="white-space:nowrap;">
                        <?php if ($r['training_date'] && $r['training_date'] !== '0000-00-00'): ?>
                        <div style="font-weight:600;"><?= date('d M', strtotime($r['training_date'])) ?></div>
                        <div style="font-size:.72rem;color:var(--muted);"><?= date('Y', strtotime($r['training_date'])) ?></div>
                        <?php else: ?><span style="color:var(--muted);font-size:.8rem;">—</span><?php endif; ?>
                    </td>
                    <td>
                        <span class="type-badge type-<?= strtolower($r['training_type']) ?>"><?= $r['training_type'] ?></span>
                    </td>
                    <td style="max-width:260px;">
                        <code class="training-code" style="font-size:.7rem;"><?= htmlspecialchars($r['course_code']) ?></code>
                        <div style="font-size:.82rem;font-weight:500;margin-top:2px;white-space:normal;line-height:1.3;">
                            <?= htmlspecialchars($r['course_title']) ?>
                        </div>
                    </td>
                    <td>
                        <strong style="font-size:.85rem;"><?= htmlspecialchars($r['staff_name']) ?></strong>
                        <div style="font-size:.72rem;color:var(--muted);"><?= htmlspecialchars($r['staff_no']) ?></div>
                    </td>
                    <td>
                        <span class="dept-badge"><?= htmlspecialchars($r['dept_name']??'—') ?></span>
                        <div style="font-size:.7rem;color:#94a3b8;margin-top:2px;"><?= $r['company'] ?></div>
                    </td>
                    <td><span class="status-badge status-<?= strtolower(str_replace(' ','-',$r['status'])) ?>"><?= $r['status'] ?></span></td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
function filterRptTable(q) {
    q = q.toLowerCase();
    document.querySelectorAll('#rptTable tbody .rpt-row').forEach(r => {
        r.style.display = r.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
}
</script>

<style>
/* ── KPI Row ────────────────────────────────────────────────────── */
.rpt-kpi-row { display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:1rem; margin-bottom:1.25rem; }
.rpt-kpi { background:#fff; border:1px solid var(--border); border-radius:12px; padding:1rem 1.25rem; display:flex; align-items:center; gap:.85rem; box-shadow:var(--shadow); }
.rpt-kpi-icon { width:42px; height:42px; border-radius:10px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
.rpt-kpi-val { font-size:1.6rem; font-weight:700; color:var(--text); line-height:1.1; }
.rpt-kpi-lbl { font-size:.7rem; color:var(--muted); font-weight:600; text-transform:uppercase; letter-spacing:.04em; margin-top:.2rem; }
.ext-val { color:#c2410c; }
.int-val { color:#15803d; }

/* ── Monthly Bar Chart ──────────────────────────────────────────── */
.monthly-chart-wrap {
    display:flex; align-items:flex-end; gap:4px;
    padding:1rem 1.25rem 0;
    height:180px; /* total height of chart area */
    position:relative;
}
.month-col {
    flex:1; display:flex; flex-direction:column; align-items:center;
    cursor:pointer; text-decoration:none; position:relative;
    padding-bottom:2rem; /* space for month label */
}
.month-col:hover .month-bars { opacity:.85; }
.month-active { }
.month-bars {
    width:100%; display:flex; align-items:flex-end; gap:1px;
    height:110px;
    border-bottom:2px solid var(--border);
    padding-bottom:2px;
}
.month-bar-ext {
    flex:1; background:#f97316; border-radius:3px 3px 0 0;
    min-height:0; transition:height .5s;
}
.month-bar-int {
    flex:1; background:#22c55e; border-radius:3px 3px 0 0;
    min-height:0; transition:height .5s;
}
.month-total { font-size:.7rem; font-weight:700; color:var(--muted); margin-top:.2rem; min-height:1em; }
.month-name { font-size:.7rem; color:var(--muted); font-weight:600; margin-top:.15rem; }
.month-name-active { color:var(--navy); font-weight:700; }
.month-active .month-bars { outline:2px solid var(--navy); outline-offset:2px; border-radius:3px; }

/* tooltip on active month */
.month-detail-tip {
    position:absolute; bottom:100%; left:50%; transform:translateX(-50%);
    background:var(--navy); color:#fff; border-radius:8px;
    padding:.45rem .65rem; font-size:.72rem; white-space:nowrap;
    box-shadow:0 4px 12px rgba(0,0,0,.2); z-index:10; margin-bottom:.25rem;
}
.month-detail-tip::after {
    content:''; position:absolute; top:100%; left:50%; transform:translateX(-50%);
    border:5px solid transparent; border-top-color:var(--navy);
}
.mdt-row { line-height:1.6; }
.mdt-ext { color:#fb923c; }
.mdt-int { color:#4ade80; }

/* ── Type Split Bars ────────────────────────────────────────────── */
.type-split-bars { display:flex; flex-direction:column; gap:.9rem; }
.tsplit-item { display:flex; flex-direction:column; gap:.25rem; }
.tsplit-label { display:flex; align-items:center; gap:.4rem; font-size:.82rem; font-weight:600; }
.tsplit-pct { margin-left:auto; color:var(--muted); font-weight:400; }
.tsplit-track { height:12px; background:var(--border); border-radius:99px; overflow:hidden; }
.tsplit-fill { height:100%; border-radius:99px; transition:width .6s; }
.tsplit-count { font-size:.78rem; color:var(--muted); text-align:right; }
.tsplit-dot { display:inline-block; width:10px; height:10px; border-radius:2px; }
.ext-dot-sq { background:#f97316; }
.int-dot-sq { background:#22c55e; }

/* ── Filter label ───────────────────────────────────────────────── */
.filter-label { display:block; font-size:.73rem; font-weight:600; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; margin-bottom:.3rem; }

/* ── Type badges (reuse from training.php) ──────────────────────── */
.type-badge { display:inline-block; padding:.15rem .55rem; border-radius:20px; font-size:.72rem; font-weight:700; }
.type-external { background:#fff7ed; color:#c2410c; border:1px solid #fed7aa; }
.type-internal { background:#f0fdf4; color:#15803d; border:1px solid #bbf7d0; }

@media print {
    .filter-bar, .header-actions, .sidebar, .topbar { display:none !important; }
    .main-content { margin:0 !important; padding:0 !important; }
    .card { box-shadow:none !important; border:1px solid #e5e7eb !important; }
}
</style>
