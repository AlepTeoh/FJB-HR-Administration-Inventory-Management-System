<?php
// rooms_public.php — Public meeting room view (no login required)
// Staff can browse rooms & availability, then login to confirm a booking
require_once 'includes/config.php';

// If already logged in, redirect to dashboard rooms page
require_once 'includes/auth.php';
if (isLoggedIn()) { header('Location: dashboard.php?page=rooms'); exit; }

$pdo = getDB();
require_once 'includes/migrate.php';
migrateBookingColumns($pdo);

$viewDate = $_GET['date'] ?? date('Y-m-d');

// Restore pending booking from session after login redirect
$pendingBooking = $_SESSION['pending_booking'] ?? null;

$rooms = $pdo->query("SELECT mr.*, u.name as pic_name FROM meeting_rooms mr LEFT JOIN users u ON mr.pic_user_id = u.id ORDER BY mr.id")->fetchAll();

$stmt = $pdo->prepare("
    SELECT rb.*, mr.name as room_name, mr.color_class
    FROM room_bookings rb
    JOIN meeting_rooms mr ON rb.room_id = mr.id
    WHERE rb.booking_date = ?
    ORDER BY rb.room_id, rb.start_time
");
$stmt->execute([$viewDate]);
$dayBookings = $stmt->fetchAll();
$bookingsByRoom = [];
foreach ($dayBookings as $b) { $bookingsByRoom[$b['room_id']][] = $b; }

function toMinutes($t) { [$h,$m] = explode(':', $t); return (int)$h*60+(int)$m; }
$GRID_START = 7*60; $GRID_END = 20*60; $GRID_SPAN = $GRID_END - $GRID_START;
function timelineLeft($t)     { global $GRID_START,$GRID_SPAN; return max(0,min(100,(toMinutes($t)-$GRID_START)/$GRID_SPAN*100)); }
function timelineWidth($s,$e) { global $GRID_START,$GRID_SPAN; return max(1,min(100,(toMinutes($e)-toMinutes($s))/$GRID_SPAN*100)); }
$nowMin  = (int)date('H')*60+(int)date('i');
$isToday = ($viewDate === date('Y-m-d'));
$nowPct  = ($isToday && $nowMin>=$GRID_START && $nowMin<=$GRID_END) ? (($nowMin-$GRID_START)/$GRID_SPAN*100) : -1;

$colorMap = [
    'room-blue'  => ['dot'=>'#185FA5','light'=>'#E6F1FB'],
    'room-green' => ['dot'=>'#1D9E75','light'=>'#E1F5EE'],
    'room-amber' => ['dot'=>'#BA7517','light'=>'#FAEEDA'],
    'room-teal'  => ['dot'=>'#1D9E75','light'=>'#E1F5EE'],
    'room-red'   => ['dot'=>'#A32D2D','light'=>'#FCEBEB'],
    'room-orange'=> ['dot'=>'#BA7517','light'=>'#FFF3E0'],
    'room-purple'=> ['dot'=>'#534AB7','light'=>'#EEEDFE'],
    'room-yellow'=> ['dot'=>'#BA7517','light'=>'#FFFDE7'],
];
$roomEmojis = ['🏛️','🔍','🎓','🌊','⭐','🏢','💡','📋'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Meeting Room Availability — HR Admin System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Serif+Display&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
<style>
  body { background: #f8fafc; font-family: 'DM Sans', sans-serif; margin: 0; }
  .pub-topbar { background: #fff; border-bottom: 1px solid #e2e8f0; padding: .85rem 1.5rem; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 1px 4px rgba(0,0,0,.05); }
  .pub-brand  { display: flex; align-items: center; gap: .6rem; font-weight: 700; font-size: 1rem; color: #1e293b; }
  .pub-brand svg { color: #6366f1; }
  .pub-login-btn { background: #6366f1; color: #fff; border: none; padding: .5rem 1.1rem; border-radius: 8px; font-size: .875rem; font-weight: 600; cursor: pointer; text-decoration: none; }
  .pub-login-btn:hover { background: #4f46e5; }
  .pub-notice { background: linear-gradient(135deg,#6366f1 0%,#8b5cf6 100%); color: #fff; padding: .85rem 1.5rem; display: flex; align-items: center; gap: .75rem; font-size: .875rem; }
  .pub-notice strong { font-weight: 700; }
  .pub-notice a { color: #fde68a; font-weight: 700; text-decoration: underline; }
  .pub-container { max-width: 1100px; margin: 0 auto; padding: 1.5rem 1.25rem; }
  .pub-hero { margin-bottom: 1.5rem; }
  .pub-hero h1 { font-size: 1.4rem; font-weight: 700; color: #1e293b; margin: 0 0 .25rem; }
  .pub-hero p  { color: #64748b; font-size: .9rem; margin: 0; }
</style>
</head>
<body>
<div class="pub-topbar">
  <div class="pub-brand">
    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>
    HR Admin System
  </div>
  <a href="index.php" class="pub-login-btn">🔐 Staff Login</a>
</div>

<div class="pub-notice">
  <span>👋</span>
  <span>You're viewing as a <strong>guest</strong>. Browse room availability freely — <a href="index.php">login</a> to make a booking.</span>
</div>

<div class="pub-container">
  <div class="pub-hero">
    <h1>📅 Meeting Room Availability</h1>
    <p>See real-time availability for all meeting rooms. Pending bookings also block time slots (first-come, first-served).</p>
  </div>

  <!-- Date navigation -->
  <div class="rb-date-strip" style="margin-bottom:1.25rem;">
    <div class="rb-date-info">
      <span class="rb-date-main"><?= date('l, d F Y', strtotime($viewDate)) ?></span>
      <?php $freeCount = count(array_filter($rooms, fn($r) => empty($bookingsByRoom[$r['id']]))); ?>
      <span class="rb-date-sub"><?= $freeCount ?> of <?= count($rooms) ?> rooms free today</span>
    </div>
    <div class="rb-date-nav">
      <a href="?date=<?= date('Y-m-d', strtotime($viewDate.' -1 day')) ?>" class="btn btn-outline btn-sm">← Prev</a>
      <a href="?" class="btn btn-sm rb-today-btn">Today</a>
      <a href="?date=<?= date('Y-m-d', strtotime($viewDate.' +1 day')) ?>" class="btn btn-outline btn-sm">Next →</a>
    </div>
  </div>

  <!-- Legend -->
  <div style="display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:1rem;font-size:.78rem;color:#64748b;">
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:2px;background:#185FA5;opacity:.7;margin-right:4px;vertical-align:middle;"></span>Approved booking</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:2px;background:#d97706;opacity:.7;margin-right:4px;vertical-align:middle;border:1px dashed #d97706;"></span>Pending (slot held)</span>
  </div>

  <div class="rb-rooms-grid">
  <?php foreach ($rooms as $i => $rm):
    $rid    = $rm['id'];
    $rmBkgs = $bookingsByRoom[$rid] ?? [];
    $clr    = $colorMap[$rm['color_class']] ?? $colorMap['room-blue'];
    $emoji  = $roomEmojis[$i % count($roomEmojis)];
    $isBusy = $isToday && !empty(array_filter($rmBkgs, fn($b) =>
        in_array($b['status'],['Approved','Pending']) &&
        toMinutes($b['start_time']) <= $nowMin && toMinutes($b['end_time']) > $nowMin));
    $activeCount = count(array_filter($rmBkgs, fn($b) => in_array($b['status'],['Approved','Pending','CancelRequested'])));
  ?>
  <div class="rb-room-card">
    <div class="rb-card-header">
      <div class="rb-room-icon" style="background:<?= $clr['light'] ?>"><?= $emoji ?></div>
      <div class="rb-room-info">
        <div class="rb-room-name"><?= htmlspecialchars($rm['name']) ?></div>
        <div class="rb-room-meta">
          <span>👥 Up to <?= (int)$rm['capacity'] ?></span>
          <span><?= $activeCount ?> booking<?= $activeCount!==1?'s':'' ?> today</span>
          <?php if (!empty($rm['pic_name'])): ?>
          <span title="Person-in-Charge">🔑 <?= htmlspecialchars($rm['pic_name']) ?></span>
          <?php endif; ?>
        </div>
      </div>
      <span class="rb-avail-badge <?= $isBusy?'rb-badge-busy':'rb-badge-free' ?>"><?= $isBusy?'In Use':'Free Now' ?></span>
    </div>

    <div class="rb-timeline-wrap">
      <div class="rb-timeline-track">
        <?php foreach ($rmBkgs as $b):
          if ($b['status'] === 'Rejected') continue;
          $left  = timelineLeft($b['start_time']);
          $width = timelineWidth($b['start_time'], $b['end_time']);
          $isPending = in_array($b['status'],['Pending','CancelRequested']);
          $blockStyle = $isPending
            ? 'background:#d97706!important;opacity:.75;border:1px dashed #92400e'
            : 'opacity:.7';
        ?>
        <div class="rb-timeline-block rb-block-other"
             style="left:<?= round($left,2) ?>%;width:<?= round($width,2) ?>%;<?= $blockStyle ?>"
             title="<?= date('H:i',strtotime($b['start_time'])) ?>–<?= date('H:i',strtotime($b['end_time'])) ?> [<?= $b['status'] ?>]">
          <span><?= date('H:i',strtotime($b['start_time'])) ?></span>
        </div>
        <?php endforeach; ?>
        <?php if ($nowPct >= 0): ?>
        <div class="rb-now-line" style="left:<?= round($nowPct,2) ?>%"></div>
        <?php endif; ?>
      </div>
      <div class="rb-timeline-labels">
        <span>7am</span><span>9</span><span>11</span><span>1pm</span><span>3</span><span>5</span><span>8pm</span>
      </div>
    </div>

    <div class="rb-bookings-list">
      <?php $visible = array_filter($rmBkgs, fn($b) => $b['status'] !== 'Rejected'); ?>
      <?php if (empty($visible)): ?>
      <div class="rb-empty-day">
        <strong style="color:#3B6D11;display:block;margin-bottom:.15rem;">✓ All clear today!</strong>
        No meetings scheduled yet.
      </div>
      <?php else: foreach ($visible as $b):
        $statusColor = match($b['status']) { 'Approved'=>'#16a34a','CancelRequested'=>'#d97706',default=>'#d97706' };
        $statusLabel = match($b['status']) { 'Approved'=>'Approved','CancelRequested'=>'⏳ Pending cancel',default=>'Pending' };
      ?>
      <div class="rb-booking-pill">
        <span class="rb-pill-time"><?= date('H:i',strtotime($b['start_time'])) ?>–<?= date('H:i',strtotime($b['end_time'])) ?></span>
        <span class="rb-pill-purpose"><?= htmlspecialchars($b['purpose']) ?></span>
        <span style="font-size:.75rem;font-weight:600;color:<?= $statusColor ?>;white-space:nowrap;"><?= $statusLabel ?></span>
      </div>
      <?php endforeach; endif; ?>
    </div>

    <div class="rb-card-footer">
      <button class="rb-book-btn" onclick="openGuestBookModal(<?= $rm['id'] ?>, <?= htmlspecialchars(json_encode($rm['name'])) ?>)">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Book <?= htmlspecialchars($rm['name']) ?>
      </button>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
</div>

<!-- GUEST BOOKING MODAL — collects details, then redirects to login -->
<div class="modal" id="guestBookModal">
  <div class="modal-box" style="max-width:520px;width:100%">
    <div class="modal-header">
      <h3>Book <span id="guestRoomName"></span></h3>
      <button class="modal-close" onclick="closeModal()">×</button>
    </div>
    <div style="margin:1rem 1.5rem 0;padding:.75rem 1rem;background:#EEF2FF;border-radius:8px;font-size:.83rem;color:#3730a3;border:1px solid #a5b4fc;display:flex;align-items:flex-start;gap:.5rem;">
      <span>🔐</span>
      <span>You'll be asked to <strong>log in</strong> after filling in your booking details. Your details will be saved automatically.</span>
    </div>
    <div id="guestConflictWarn" style="display:none;margin:1rem 1.5rem 0;" class="alert alert-warning">
      ⚠️ That time slot is already taken. Please choose a different time.
    </div>

    <div style="padding:1rem 1.5rem 0;">
      <div style="padding:.75rem 1rem;background:#FFF3E0;border-radius:8px;font-size:.83rem;color:#7c4a00;border:1px solid #FBBF24;">
        ℹ️ Booking is <strong>first-come, first-served</strong>. Your slot is held immediately upon login, pending PIC approval.
      </div>
    </div>

    <div style="padding:1rem 1.5rem 0;">
      <div class="form-grid" style="grid-template-columns:1fr 1fr;gap:.75rem;">
        <div class="form-group" style="grid-column:1/3;">
          <label>Date <span style="color:#1D9E75">*</span></label>
          <input type="date" id="guestDate" value="<?= $viewDate ?>" min="<?= date('Y-m-d') ?>" onchange="buildClockScrolls();guestCheckConflict()">
        </div>

        <!-- Digital clock time pickers -->
        <div class="form-group">
          <label>Start Time <span style="color:#1D9E75">*</span></label>
          <div class="clock-picker" id="startClockWrap">
            <div class="clock-display" id="startDisplay" onclick="toggleClock('start')">
              <span class="clock-icon">🕐</span>
              <span id="startVal">-- : --</span>
              <span class="clock-caret">▾</span>
            </div>
            <div class="clock-dropdown" id="startDrop" style="display:none">
              <div class="clock-row">
                <div class="clock-col">
                  <div class="clock-label">Hour</div>
                  <div class="clock-scroll" id="startHourScroll"></div>
                </div>
                <div class="clock-sep">:</div>
                <div class="clock-col">
                  <div class="clock-label">Minute</div>
                  <div class="clock-scroll" id="startMinScroll"></div>
                </div>
              </div>
              <div class="clock-confirm" onclick="confirmClock('start')">Set Start Time</div>
            </div>
          </div>
          <input type="hidden" id="guestStart">
        </div>

        <div class="form-group">
          <label>End Time <span style="color:#1D9E75">*</span></label>
          <div class="clock-picker" id="endClockWrap">
            <div class="clock-display" id="endDisplay" onclick="toggleClock('end')">
              <span class="clock-icon">🕑</span>
              <span id="endVal">-- : --</span>
              <span class="clock-caret">▾</span>
            </div>
            <div class="clock-dropdown" id="endDrop" style="display:none">
              <div class="clock-row">
                <div class="clock-col">
                  <div class="clock-label">Hour</div>
                  <div class="clock-scroll" id="endHourScroll"></div>
                </div>
                <div class="clock-sep">:</div>
                <div class="clock-col">
                  <div class="clock-label">Minute</div>
                  <div class="clock-scroll" id="endMinScroll"></div>
                </div>
              </div>
              <div class="clock-confirm" onclick="confirmClock('end')">Set End Time</div>
            </div>
          </div>
          <input type="hidden" id="guestEnd">
        </div>
      </div>

      <div style="margin-top:.75rem;">
        <div style="font-size:.8rem;color:#64748b;margin-bottom:.4rem;">Quick duration</div>
        <div class="rb-dur-pills">
          <span class="rb-dur-pill" onclick="guestSetDuration(30,this)">30 min</span>
          <span class="rb-dur-pill" onclick="guestSetDuration(60,this)">1 hour</span>
          <span class="rb-dur-pill" onclick="guestSetDuration(90,this)">1.5 hrs</span>
          <span class="rb-dur-pill" onclick="guestSetDuration(120,this)">2 hours</span>
          <span class="rb-dur-pill" onclick="guestSetDuration(180,this)">Half day</span>
        </div>
      </div>

      <div class="form-group" style="margin-top:1rem;">
        <label>Meeting Purpose <span style="color:#1D9E75">*</span></label>
        <textarea id="guestPurpose" rows="3" placeholder="e.g. Team standup, Interview, Project review…"></textarea>
      </div>
    </div>

    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" onclick="proceedToLogin()">Continue to Login →</button>
    </div>
  </div>
</div>

<style>
/* Digital clock picker */
.clock-picker { position: relative; }
.clock-display {
  display: flex; align-items: center; gap: .5rem;
  border: 1.5px solid #e2e8f0; border-radius: 8px; padding: .55rem .75rem;
  cursor: pointer; font-size: .95rem; font-weight: 600; color: #1e293b;
  background: #fff; transition: border-color .15s;
}
.clock-display:hover, .clock-display.open { border-color: #6366f1; background: #f8f7ff; }
.clock-icon { font-size: 1rem; }
.clock-caret { margin-left:auto; font-size:.7rem; color:#94a3b8; }
.clock-dropdown {
  position: absolute; top: calc(100% + 4px); left: 0; z-index: 999;
  background: #fff; border: 1.5px solid #e2e8f0; border-radius: 12px;
  box-shadow: 0 8px 30px rgba(0,0,0,.13); padding: 1rem; min-width: 220px;
}
.clock-row { display: flex; gap: .5rem; align-items: flex-start; }
.clock-col { flex: 1; }
.clock-label { font-size: .72rem; font-weight: 700; color: #94a3b8; text-align: center; text-transform: uppercase; letter-spacing: .04em; margin-bottom: .35rem; }
.clock-sep { font-size: 1.4rem; font-weight: 700; color: #6366f1; padding-top: 1.8rem; }
.clock-scroll {
  max-height: 160px; overflow-y: auto; border: 1px solid #e2e8f0; border-radius: 8px;
  scrollbar-width: thin;
}
.clock-scroll::-webkit-scrollbar { width: 4px; }
.clock-scroll::-webkit-scrollbar-thumb { background: #c7d2fe; border-radius: 4px; }
.clock-num {
  padding: .45rem .5rem; text-align: center; font-size: .9rem; font-weight: 500;
  cursor: pointer; transition: background .1s, color .1s; border-radius: 4px; margin: 1px;
}
.clock-num:hover   { background: #eef2ff; color: #6366f1; }
.clock-num.selected{ background: #6366f1; color: #fff; font-weight: 700; }
.clock-num.disabled{ opacity: 0.3; cursor: not-allowed; text-decoration: line-through; pointer-events: none; }
.clock-confirm {
  margin-top: .75rem; text-align: center; background: #6366f1; color: #fff;
  border-radius: 8px; padding: .55rem; font-size: .85rem; font-weight: 600;
  cursor: pointer; transition: background .15s;
}
.clock-confirm:hover { background: #4f46e5; }
</style>

<script>
const guestBookings = <?= json_encode(array_values($dayBookings)) ?>;
const guestRooms    = <?= json_encode(array_values($rooms)) ?>;
let guestRoomId = null;
let clockState  = { start: {h:null, m:null}, end: {h:null, m:null} };

// ── Time helpers ──────────────────────────────────────────────────────
function gToMin(t) { if(!t) return 0; const [h,m]=t.substring(0,5).split(':').map(Number); return h*60+m; }
function gGetNowMin() { const n=new Date(); return n.getHours()*60+n.getMinutes(); }
function gIsToday(date) { return date===new Date().toISOString().slice(0,10); }

function gIsStartDisabled(h, m) {
    const tMin = h*60+m;
    const date = document.getElementById('guestDate').value;
    if (gIsToday(date) && tMin <= gGetNowMin()) return true;
    if (!guestRoomId || !date) return false;
    return guestBookings.some(b =>
        b.room_id == guestRoomId && b.booking_date === date &&
        !['Rejected'].includes(b.status) &&
        tMin >= gToMin(b.start_time) && tMin < gToMin(b.end_time)
    );
}

function gIsEndDisabled(h, m) {
    const tMin = h*60+m;
    const date = document.getElementById('guestDate').value;
    const startH = clockState.start.h, startM = clockState.start.m;
    const startMin = (startH!==null && startM!==null) ? startH*60+startM : null;
    if (startMin !== null && tMin <= startMin) return true;
    if (gIsToday(date) && tMin <= gGetNowMin()) return true;
    if (startMin !== null && guestRoomId && date) {
        return guestBookings.some(b =>
            b.room_id == guestRoomId && b.booking_date === date &&
            !['Rejected'].includes(b.status) &&
            startMin < gToMin(b.end_time) && tMin > gToMin(b.start_time)
        );
    }
    return false;
}

function buildClockScrolls() {
    ['start','end'].forEach(which => {
        const hEl = document.getElementById(which+'HourScroll');
        const mEl = document.getElementById(which+'MinScroll');
        hEl.innerHTML = ''; mEl.innerHTML = '';

        for (let h = 7; h <= 20; h++) {
            const allOff = [0,15,30,45].every(m =>
                which === 'start' ? gIsStartDisabled(h,m) : gIsEndDisabled(h,m)
            );
            const d = document.createElement('div');
            d.className = 'clock-num' + (allOff ? ' disabled' : '');
            d.textContent = String(h).padStart(2,'0');
            if (!allOff) d.onclick = () => selectClockNum(which, 'h', h, d);
            hEl.appendChild(d);
        }

        [0,15,30,45].forEach(m => {
            const d = document.createElement('div');
            d.className = 'clock-num';
            d.textContent = String(m).padStart(2,'0');
            d.dataset.minute = m;
            d.onclick = function() {
                if (!this.classList.contains('disabled')) selectClockNum(which, 'm', m, d);
            };
            mEl.appendChild(d);
        });
    });
}

function refreshGuestMinutes(which) {
    const h = clockState[which].h;
    if (h === null) return;
    const mEl = document.getElementById(which+'MinScroll');
    mEl.querySelectorAll('.clock-num').forEach(el => {
        const m = parseInt(el.dataset.minute);
        const off = which === 'start' ? gIsStartDisabled(h,m) : gIsEndDisabled(h,m);
        el.classList.toggle('disabled', off);
        el.onclick = off ? null : () => selectClockNum(which, 'm', m, el);
        if (off && el.classList.contains('selected')) {
            el.classList.remove('selected');
            clockState[which].m = null;
            document.getElementById('guest'+which.charAt(0).toUpperCase()+which.slice(1)).value='';
            document.getElementById(which+'Val').textContent='-- : --';
        }
    });
}

function selectClockNum(which, part, val, el) {
  const scrollId = which + (part==='h' ? 'HourScroll' : 'MinScroll');
  document.querySelectorAll('#'+scrollId+' .clock-num').forEach(x => x.classList.remove('selected'));
  el.classList.add('selected');
  clockState[which][part] = val;
  if (part === 'h') {
    refreshGuestMinutes(which);
    if (which === 'start') { buildClockScrolls(); refreshGuestMinutes('end'); }
  }
  // Update display preview
  const h = clockState[which].h, m = clockState[which].m;
  if (h !== null && m !== null) {
    document.getElementById(which+'Val').textContent = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
    document.getElementById('guest'+which.charAt(0).toUpperCase()+which.slice(1)).value =
      String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
    guestCheckConflict();
  }
}

function toggleClock(which) {
  const drop = document.getElementById(which+'Drop');
  const disp = document.getElementById(which+'Display');
  const isOpen = drop.style.display !== 'none';
  document.querySelectorAll('.clock-dropdown').forEach(d => d.style.display='none');
  document.querySelectorAll('.clock-display').forEach(d => d.classList.remove('open'));
  if (!isOpen) { drop.style.display='block'; disp.classList.add('open'); }
}

function confirmClock(which) {
  document.getElementById(which+'Drop').style.display='none';
  document.getElementById(which+'Display').classList.remove('open');
  // Auto-set end = start+1h if end not set yet
  if (which === 'start' && clockState.start.h !== null && clockState.end.h === null) {
    const endH = Math.min(clockState.start.h + 1, 20);
    const endM = clockState.start.m;
    clockState.end.h = endH;
    clockState.end.m = endM;
    const timeStr = String(endH).padStart(2,'0')+':'+String(endM).padStart(2,'0');
    document.getElementById('endVal').value = timeStr;
    document.getElementById('endVal').textContent = timeStr;
    document.getElementById('guestEnd').value = timeStr;
    // Highlight in scrolls
    document.querySelectorAll('#endHourScroll .clock-num').forEach(x => { x.classList.toggle('selected', parseInt(x.textContent)===endH); });
    document.querySelectorAll('#endMinScroll .clock-num').forEach(x => { x.classList.toggle('selected', parseInt(x.textContent)===endM); });
    guestCheckConflict();
  }
}

// Close dropdowns on outside click
document.addEventListener('click', e => {
  if (!e.target.closest('.clock-picker')) {
    document.querySelectorAll('.clock-dropdown').forEach(d => d.style.display='none');
    document.querySelectorAll('.clock-display').forEach(d => d.classList.remove('open'));
  }
});

function openGuestBookModal(roomId, roomName) {
  guestRoomId = roomId;
  document.getElementById('guestRoomName').textContent = roomName;
  document.getElementById('guestConflictWarn').style.display='none';
  document.getElementById('guestDate').value = '<?= $viewDate ?>';
  document.getElementById('guestStart').value = '';
  document.getElementById('guestEnd').value = '';
  document.getElementById('guestPurpose').value = '';
  document.getElementById('startVal').textContent = '-- : --';
  document.getElementById('endVal').textContent   = '-- : --';
  clockState = {start:{h:null,m:null}, end:{h:null,m:null}};
  document.querySelectorAll('.clock-num').forEach(x => x.classList.remove('selected'));
  document.querySelectorAll('.rb-dur-pill').forEach(p => p.classList.remove('active'));
  buildClockScrolls();
  openModal('guestBookModal');
}

function guestSetDuration(mins, el) {
  document.querySelectorAll('.rb-dur-pill').forEach(p => p.classList.remove('active'));
  el.classList.add('active');
  const st = document.getElementById('guestStart').value;
  if (!st) return;
  const [h,m] = st.split(':').map(Number);
  const endMin = h*60+m+mins;
  if (endMin <= 20*60) {
    const eh = Math.floor(endMin/60), em = endMin%60;
    const timeStr = String(eh).padStart(2,'0')+':'+String(em).padStart(2,'0');
    clockState.end.h = eh; clockState.end.m = em;
    document.getElementById('endVal').textContent = timeStr;
    document.getElementById('guestEnd').value = timeStr;
    document.querySelectorAll('#endHourScroll .clock-num').forEach(x => { x.classList.toggle('selected', parseInt(x.textContent)===eh); });
    document.querySelectorAll('#endMinScroll .clock-num').forEach(x => { x.classList.toggle('selected', parseInt(x.textContent)===em); });
    guestCheckConflict();
  }
}

function guestCheckConflict() {
  const date  = document.getElementById('guestDate').value;
  const start = document.getElementById('guestStart').value;
  const end   = document.getElementById('guestEnd').value;
  if (!guestRoomId||!date||!start||!end) return;
  const conflict = guestBookings.some(b =>
    b.room_id == guestRoomId && b.booking_date === date &&
    !['Rejected'].includes(b.status) &&
    start < (b.end_time||'').substring(0,5) && end > (b.start_time||'').substring(0,5)
  );
  document.getElementById('guestConflictWarn').style.display = conflict ? 'block' : 'none';
}

function proceedToLogin() {
  const date    = document.getElementById('guestDate').value;
  const start   = document.getElementById('guestStart').value;
  const end     = document.getElementById('guestEnd').value;
  const purpose = document.getElementById('guestPurpose').value.trim();
  if (!guestRoomId || !date || !start || !end || !purpose) {
    alert('Please fill in all fields before continuing.'); return;
  }
  const conflict = guestBookings.some(b =>
    b.room_id == guestRoomId && b.booking_date === date &&
    !['Rejected'].includes(b.status) &&
    start < (b.end_time||'').substring(0,5) && end > (b.start_time||'').substring(0,5)
  );
  if (conflict) { alert('That time slot is already taken. Please choose a different time.'); return; }
  // Store booking in URL params to pass to login page
  const params = new URLSearchParams({
    pending_room: guestRoomId, pending_date: date,
    pending_start: start, pending_end: end, pending_purpose: purpose
  });
  window.location.href = 'index.php?'+params.toString();
}
</script>

<?php
// Re-use modal JS helpers from main app
?>
<script src="assets/js/app.js"></script>
</body>
</html>
