<?php
require_once 'includes/auth.php';
if (isLoggedIn()) { header('Location: dashboard.php'); exit; }
$error = '';
$success = '';
if (isset($_GET['reset']) && $_GET['reset'] === 'success') {
    $success = 'Password reset successfully. Please sign in with your new password.';
}

// Capture pending booking params from guest page
$pendingRoom    = isset($_GET['pending_room'])    ? (int)$_GET['pending_room']          : null;
$pendingDate    = isset($_GET['pending_date'])    ? $_GET['pending_date']                : null;
$pendingStart   = isset($_GET['pending_start'])   ? $_GET['pending_start']               : null;
$pendingEnd     = isset($_GET['pending_end'])     ? $_GET['pending_end']                 : null;
$pendingPurpose = isset($_GET['pending_purpose']) ? trim($_GET['pending_purpose'])        : null;
$hasPending     = $pendingRoom && $pendingDate && $pendingStart && $pendingEnd && $pendingPurpose;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $staff_id = trim($_POST['staff_id']??'');
    $password = trim($_POST['password']??'');
    if (login($staff_id, $password)) {
        // If we came from the guest booking page, store booking in session and redirect
        $postRoom    = isset($_POST['pending_room'])    ? (int)$_POST['pending_room']    : null;
        $postDate    = isset($_POST['pending_date'])    ? $_POST['pending_date']          : null;
        $postStart   = isset($_POST['pending_start'])   ? $_POST['pending_start']         : null;
        $postEnd     = isset($_POST['pending_end'])     ? $_POST['pending_end']           : null;
        $postPurpose = isset($_POST['pending_purpose']) ? trim($_POST['pending_purpose']) : null;
        if ($postRoom && $postDate && $postStart && $postEnd && $postPurpose) {
            $_SESSION['pending_booking'] = [
                'room_id'      => $postRoom,
                'booking_date' => $postDate,
                'start_time'   => $postStart,
                'end_time'     => $postEnd,
                'purpose'      => $postPurpose,
            ];
            header('Location: dashboard.php?page=rooms&date='.$postDate.'&open_booking=1');
        } else {
            header('Location: dashboard.php');
        }
        exit;
    }
    else $error = 'Invalid Staff ID or password. Please try again.';
}
?>
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login — HR Admin System</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Serif+Display&display=swap" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="login-body">
<div class="login-wrapper">
    <div class="login-card">
        <div class="login-brand">
            <div class="brand-icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
            </div>
            <h1 class="brand-name">HR Admin System</h1>
            <p class="brand-sub">FGV Group — Human Resources &amp; Administration Portal</p>
        </div>
        <?php if ($success): ?>
        <div class="alert alert-success">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
            <?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-error">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>
        <form method="POST" class="login-form">
            <?php if ($hasPending): ?>
            <div style="background:#EEF2FF;border:1px solid #a5b4fc;border-radius:8px;padding:.75rem 1rem;margin-bottom:1rem;font-size:.83rem;color:#3730a3;">
                🗓️ <strong>Booking held for you:</strong><br>
                Room #<?= $pendingRoom ?> · <?= htmlspecialchars($pendingDate) ?> · <?= htmlspecialchars($pendingStart) ?>–<?= htmlspecialchars($pendingEnd) ?><br>
                <em style="color:#6366f1;">"<?= htmlspecialchars(substr($pendingPurpose,0,60)) ?><?= strlen($pendingPurpose)>60?'…':'' ?>"</em>
            </div>
            <input type="hidden" name="pending_room"    value="<?= $pendingRoom ?>">
            <input type="hidden" name="pending_date"    value="<?= htmlspecialchars($pendingDate) ?>">
            <input type="hidden" name="pending_start"   value="<?= htmlspecialchars($pendingStart) ?>">
            <input type="hidden" name="pending_end"     value="<?= htmlspecialchars($pendingEnd) ?>">
            <input type="hidden" name="pending_purpose" value="<?= htmlspecialchars($pendingPurpose) ?>">
            <?php endif; ?>
            <div class="form-group">
                <label for="staff_id">Staff ID</label>
                <input type="text" id="staff_id" name="staff_id" placeholder="e.g. 0000001" required value="<?= htmlspecialchars($_POST['staff_id']??'') ?>">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="Enter your password" required>
            </div>
            <button type="submit" class="btn btn-primary btn-full"><?= $hasPending ? '🔐 Sign In & Submit Booking' : 'Sign In' ?></button>
            <a href="forgot.php" style="display:block;text-align:center;margin-top:.85rem;font-size:.85rem;color:#6366f1;text-decoration:none;">Forgot password?</a>
        </form>
        <div class="login-hint">
            <p><strong>🔧 Admin (IT):</strong> 0000001 / password</p>
            <p><strong>👤 Admin (HR):</strong> 0000002 / hr123</p>
            <p><strong>👷 Staff:</strong> 3600134 / staff123</p>
        </div>
        <div style="text-align:center;margin-top:1rem;padding-top:.85rem;border-top:1px solid #e2e8f0;">
            <a href="rooms_public.php" style="font-size:.83rem;color:#6366f1;text-decoration:none;display:inline-flex;align-items:center;gap:.35rem;">
                📅 View meeting room availability without logging in
            </a>
        </div>
    </div>
</div>
</body>
</html>
