<?php
// pages/rooms.php
require_once __DIR__ . '/../includes/config.php';
$pdo  = getDB();
$user = currentUser();

// Auto-migrate: add any missing columns safely
require_once __DIR__ . '/../includes/migrate.php';
migrateBookingColumns($pdo);

$viewDate = $_GET['date'] ?? date('Y-m-d');
$rooms    = $pdo->query("SELECT mr.*, u.name as pic_name, u.id as pic_id FROM meeting_rooms mr LEFT JOIN users u ON mr.pic_user_id = u.id ORDER BY mr.id")->fetchAll();
$allUsers = $pdo->query("SELECT id, name, staff_no FROM users WHERE is_active=1 ORDER BY name")->fetchAll();

// Is current user a PIC for any room?
$myPicRoomIds = array_column(array_filter($rooms, fn($r) => $r['pic_id'] == $user['id']), 'id');
$isPic = !empty($myPicRoomIds);
$canApprove = isAdminIT() || $isPic;

$stmt = $pdo->prepare("
    SELECT rb.*, mr.name as room_name, mr.color_class, mr.capacity
    FROM room_bookings rb
    JOIN meeting_rooms mr ON rb.room_id = mr.id
    WHERE rb.booking_date = ?
    ORDER BY rb.room_id, rb.start_time
");
$stmt->execute([$viewDate]);
$dayBookings = $stmt->fetchAll();

$bookingsByRoom = [];
foreach ($dayBookings as $b) { $bookingsByRoom[$b['room_id']][] = $b; }

// Pending bookings needing approval (new bookings + cancellation requests)
$pendingForMe = [];
if ($canApprove) {
    if (isAdminIT()) {
        $pendingForMe = $pdo->query("
            SELECT rb.*, mr.name as room_name
            FROM room_bookings rb
            JOIN meeting_rooms mr ON rb.room_id = mr.id
            WHERE rb.status IN ('Pending','CancelRequested')
            ORDER BY rb.booking_date, rb.start_time
        ")->fetchAll();
    } else {
        $inList = implode(',', array_map('intval', $myPicRoomIds));
        $pendingForMe = $pdo->query("
            SELECT rb.*, mr.name as room_name
            FROM room_bookings rb
            JOIN meeting_rooms mr ON rb.room_id = mr.id
            WHERE rb.status IN ('Pending','CancelRequested') AND rb.room_id IN ($inList)
            ORDER BY rb.booking_date, rb.start_time
        ")->fetchAll();
    }
}

// Restore pending booking from session (after guest → login redirect)
$sessionBooking = null;
if (isset($_SESSION['pending_booking'])) {
    $sessionBooking = $_SESSION['pending_booking'];
    unset($_SESSION['pending_booking']); // consume it
}

function toMinutes($t) { [$h,$m] = explode(':', $t); return (int)$h*60+(int)$m; }
$GRID_START = 7 * 60; $GRID_END = 20 * 60; $GRID_SPAN = $GRID_END - $GRID_START;
function timelineLeft($t)     { global $GRID_START,$GRID_SPAN; return max(0,min(100,(toMinutes($t)-$GRID_START)/$GRID_SPAN*100)); }
function timelineWidth($s,$e) { global $GRID_START,$GRID_SPAN; return max(1,min(100,(toMinutes($e)-toMinutes($s))/$GRID_SPAN*100)); }
$nowMin  = (int)date('H')*60+(int)date('i');
$isToday = ($viewDate === date('Y-m-d'));
$nowPct  = ($isToday && $nowMin>=$GRID_START && $nowMin<=$GRID_END) ? (($nowMin-$GRID_START)/$GRID_SPAN*100) : -1;

$colorMap = [
    'room-blue'  => ['dot'=>'#185FA5','light'=>'#E6F1FB'],
    'room-green' => ['dot'=>'#1D9E75','light'=>'#E1F5EE'],
    'room-amber' => ['dot'=>'#BA7517','light'=>'#FAEEDA'],
    'room-teal'  => ['dot'=>'#1D9E75','light'=>'#E1F5EE'],
    'room-red'   => ['dot'=>'#A32D2D','light'=>'#FCEBEB'],
    'room-orange'=> ['dot'=>'#BA7517','light'=>'#FFF3E0'],
    'room-purple'=> ['dot'=>'#534AB7','light'=>'#EEEDFE'],
    'room-yellow'=> ['dot'=>'#BA7517','light'=>'#FFFDE7'],
];
$roomEmojis = ['🏛️','🔍','🎓','🌊','⭐','🏢','💡','📋'];
?>

<div class="page-header">
    <div>
        <h2>Meeting Room Booking</h2>
        <p class="page-subtitle"><?= date('l, d F Y', strtotime($viewDate)) ?></p>
    </div>
    <div style="display:flex;gap:.5rem;align-items:center;">
        <?php if (isAdminIT()): ?>
        <button class="btn btn-outline" onclick="openModal('manageRoomsModal')">Manage Rooms</button>
        <?php endif; ?>
        <button class="btn btn-primary" onclick="openRoomBookingModal(null,null,null)">+ New Booking</button>
    </div>
</div>

<?php if ($canApprove && count($pendingForMe) > 0): ?>
<div class="card" style="border-left:4px solid var(--warning,#d97706);margin-bottom:1.5rem;">
    <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:1rem;">
        <span style="font-size:1.2rem;">🔔</span>
        <strong style="font-size:.95rem;">Pending Actions — <?= count($pendingForMe) ?> item<?= count($pendingForMe)!==1?'s':'' ?> awaiting your action</strong>
    </div>
    <table class="table" style="font-size:.85rem;">
        <thead><tr><th>Type</th><th>Room</th><th>Booked By</th><th>Date</th><th>Time</th><th>Purpose</th><th style="min-width:200px;">Action</th></tr></thead>
        <tbody>
        <?php foreach ($pendingForMe as $pb):
            $isCancelReq = ($pb['status'] === 'CancelRequested');
        ?>
        <tr style="<?= $isCancelReq ? 'background:#faf5ff;' : '' ?>">
            <td>
                <?php if ($isCancelReq): ?>
                <span style="font-size:.75rem;font-weight:700;color:#7c3aed;background:#ede9fe;padding:2px 7px;border-radius:20px;">⚠️ Cancel Req.</span>
                <?php else: ?>
                <span style="font-size:.75rem;font-weight:700;color:#d97706;background:#fef3c7;padding:2px 7px;border-radius:20px;">📅 New Booking</span>
                <?php endif; ?>
            </td>
            <td><strong><?= htmlspecialchars($pb['room_name']) ?></strong></td>
            <td><?= htmlspecialchars($pb['booked_by_name']) ?></td>
            <td><?= date('d M Y', strtotime($pb['booking_date'])) ?></td>
            <td><?= date('H:i',strtotime($pb['start_time'])) ?>–<?= date('H:i',strtotime($pb['end_time'])) ?></td>
            <td>
                <?= htmlspecialchars($pb['purpose']) ?>
                <?php if ($isCancelReq && $pb['cancel_reason']): ?>
                <br><small style="color:#7c3aed;font-style:italic;">Reason: <?= htmlspecialchars($pb['cancel_reason']) ?></small>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($isCancelReq): ?>
                <form method="POST" action="actions/booking.php" style="display:inline">
                    <input type="hidden" name="action" value="approve_cancel">
                    <input type="hidden" name="id" value="<?= $pb['id'] ?>">
                    <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
                    <button type="submit" class="btn btn-sm" style="background:#7c3aed;color:#fff;border:none;">✓ Allow Cancel</button>
                </form>
                <form method="POST" action="actions/booking.php" style="display:inline;margin-left:.25rem;">
                    <input type="hidden" name="action" value="reject_cancel">
                    <input type="hidden" name="id" value="<?= $pb['id'] ?>">
                    <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
                    <button type="submit" class="btn btn-sm btn-danger">✕ Keep Booking</button>
                </form>
                <?php else: ?>
                <form method="POST" action="actions/booking.php" style="display:inline">
                    <input type="hidden" name="action" value="approve">
                    <input type="hidden" name="id" value="<?= $pb['id'] ?>">
                    <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
                    <button type="submit" class="btn btn-sm" style="background:#16a34a;color:#fff;border:none;">✓ Approve</button>
                </form>
                <button class="btn btn-sm btn-danger" onclick="openRejectModal(<?= $pb['id'] ?>, '<?= addslashes($pb['booked_by_name']) ?>')" style="margin-left:.25rem;">✕ Reject</button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div class="rb-date-strip">
    <div class="rb-date-info">
        <span class="rb-date-main"><?= date('l, d F Y', strtotime($viewDate)) ?></span>
        <?php $freeCount = count(array_filter($rooms, fn($r) => empty($bookingsByRoom[$r['id']]))); ?>
        <span class="rb-date-sub"><?= $freeCount ?> of <?= count($rooms) ?> rooms free today</span>
    </div>
    <div class="rb-date-nav">
        <a href="?page=rooms&date=<?= date('Y-m-d', strtotime($viewDate.' -1 day')) ?>" class="btn btn-outline btn-sm">← Prev</a>
        <a href="?page=rooms&date=<?= date('Y-m-d') ?>" class="btn btn-sm rb-today-btn">Today</a>
        <a href="?page=rooms&date=<?= date('Y-m-d', strtotime($viewDate.' +1 day')) ?>" class="btn btn-outline btn-sm">Next →</a>
    </div>
</div>

<?php if ($isToday): ?>
<div class="rb-quick-banner">
    <div class="rb-quick-icon">⚡</div>
    <div class="rb-quick-text">
        <strong>Need a room right now?</strong>
        <span>See which rooms are free at this moment and grab one instantly.</span>
    </div>
    <button class="btn rb-quick-btn" onclick="quickBookNow()">Find Available Room</button>
</div>
<?php endif; ?>

<!-- Timeline legend -->
<div style="display:flex;gap:1rem;flex-wrap:wrap;margin-bottom:1rem;font-size:.78rem;color:var(--muted);">
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:2px;background:#185FA5;opacity:.7;margin-right:4px;vertical-align:middle;"></span>Your booking (approved)</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:2px;background:#888;opacity:.5;margin-right:4px;vertical-align:middle;"></span>Others' booking</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:2px;background:#d97706;opacity:.7;margin-right:4px;vertical-align:middle;border:1px dashed #d97706;"></span>Pending approval</span>
    <span><span style="display:inline-block;width:12px;height:12px;border-radius:2px;background:#dc2626;opacity:.4;margin-right:4px;vertical-align:middle;"></span>Rejected</span>
</div>

<div class="rb-rooms-grid">
<?php foreach ($rooms as $i => $rm):
    $rid    = $rm['id'];
    $rmBkgs = $bookingsByRoom[$rid] ?? [];
    $clr    = $colorMap[$rm['color_class']] ?? $colorMap['room-blue'];
    $emoji  = $roomEmojis[$i % count($roomEmojis)];
    $isBusy = $isToday && !empty(array_filter($rmBkgs, fn($b) =>
        $b['status'] === 'Approved' &&
        toMinutes($b['start_time']) <= $nowMin && toMinutes($b['end_time']) > $nowMin));
?>
<div class="rb-room-card">
    <div class="rb-card-header">
        <div class="rb-room-icon" style="background:<?= $clr['light'] ?>"><?= $emoji ?></div>
        <div class="rb-room-info">
            <div class="rb-room-name"><?= htmlspecialchars($rm['name']) ?></div>
            <div class="rb-room-meta">
                <span>👥 Up to <?= (int)$rm['capacity'] ?></span>
                <span><?= count($rmBkgs) ?> booking<?= count($rmBkgs)!==1?'s':'' ?> today</span>
                <?php if (!empty($rm['pic_name'])): ?>
                <span title="Person-in-Charge">🔑 <?= htmlspecialchars($rm['pic_name']) ?></span>
                <?php else: ?>
                <span style="color:var(--muted);font-style:italic;font-size:.78rem;">No PIC</span>
                <?php endif; ?>
            </div>
        </div>
        <span class="rb-avail-badge <?= $isBusy?'rb-badge-busy':'rb-badge-free' ?>"><?= $isBusy?'In Use':'Free Now' ?></span>
    </div>

    <div class="rb-timeline-wrap">
        <div class="rb-timeline-track">
            <?php foreach ($rmBkgs as $b):
                $left  = timelineLeft($b['start_time']);
                $width = timelineWidth($b['start_time'], $b['end_time']);
                $mine  = ($b['booked_by_id'] == $user['id']);
                $blockStyle = match($b['status']) {
                    'Approved' => $mine ? '' : 'opacity:.5',
                    'Rejected' => 'opacity:.25;background:#dc2626!important',
                    default    => 'background:#d97706!important;opacity:.75;border:1px dashed #92400e',
                };
            ?>
            <div class="rb-timeline-block <?= ($b['status']==='Approved' && $mine)?'rb-block-mine':($b['status']==='Approved'?'rb-block-other':'') ?>"
                 style="left:<?= round($left,2) ?>%;width:<?= round($width,2) ?>%;<?= $blockStyle ?>"
                 title="<?= htmlspecialchars($b['purpose']) ?> — <?= $b['booked_by_name'] ?> (<?= date('H:i',strtotime($b['start_time'])) ?>–<?= date('H:i',strtotime($b['end_time'])) ?>) [<?= $b['status'] ?>]">
                <span><?= date('H:i',strtotime($b['start_time'])) ?></span>
            </div>
            <?php endforeach; ?>
            <?php if ($nowPct >= 0): ?>
            <div class="rb-now-line" style="left:<?= round($nowPct,2) ?>%"></div>
            <?php endif; ?>
        </div>
        <div class="rb-timeline-labels">
            <span>7am</span><span>9</span><span>11</span><span>1pm</span><span>3</span><span>5</span><span>8pm</span>
        </div>
    </div>

    <div class="rb-bookings-list">
        <?php if (empty($rmBkgs)): ?>
        <div class="rb-empty-day">
            <strong style="color:#3B6D11;display:block;margin-bottom:.15rem;">✓ All clear today!</strong>
            No meetings scheduled yet.
        </div>
        <?php else: foreach ($rmBkgs as $b):
            $isOwner      = ($b['booked_by_id'] == $user['id']);
            $isPicForRoom = in_array($b['room_id'], $myPicRoomIds);
            // Only owner can edit their own PENDING booking
            $canEdit      = $isOwner && $b['status'] === 'Pending';
            // Owner can request cancellation (Pending or Approved — but not already CancelRequested or Rejected)
            $canCancel    = $isOwner && !in_array($b['status'], ['Rejected','CancelRequested']);
            // PIC or IT Admin can approve/reject pending bookings (not their own)
            $canApproveThis = (isAdminIT() || $isPicForRoom) && $b['status'] === 'Pending' && !$isOwner;
            // PIC or IT Admin can approve/reject cancel requests
            $canApproveCancel = (isAdminIT() || $isPicForRoom) && $b['status'] === 'CancelRequested';
            $statusColor = match($b['status']) { 'Approved'=>'#16a34a','Rejected'=>'#dc2626','CancelRequested'=>'#7c3aed',default=>'#d97706' };
            $statusIcon  = match($b['status']) { 'Approved'=>'✓','Rejected'=>'✕','CancelRequested'=>'⏳',default=>'⏳' };
            $statusLabel = match($b['status']) { 'Approved'=>'Approved','Rejected'=>'Rejected','CancelRequested'=>'Cancel Requested',default=>'Pending' };
        ?>
        <div class="rb-booking-pill" style="<?= $b['status']==='Rejected'?'opacity:.55':'' ?>">
            <span class="rb-pill-time"><?= date('H:i',strtotime($b['start_time'])) ?>–<?= date('H:i',strtotime($b['end_time'])) ?></span>
            <span class="rb-pill-purpose"><?= htmlspecialchars($b['purpose']) ?></span>
            <span class="rb-pill-by"><?= htmlspecialchars($b['booked_by_name']) ?></span>
            <span style="font-size:.75rem;font-weight:600;color:<?= $statusColor ?>;white-space:nowrap;"><?= $statusIcon ?> <?= $statusLabel ?></span>
            <?php if ($b['status']==='Rejected' && $b['rejection_reason']): ?>
            <span style="font-size:.72rem;color:var(--muted);white-space:nowrap;" title="<?= htmlspecialchars($b['rejection_reason']) ?>">— <?= htmlspecialchars(substr($b['rejection_reason'],0,30)) ?><?= strlen($b['rejection_reason'])>30?'…':'' ?></span>
            <?php endif; ?>
            <?php if ($canEdit): ?>
            <button class="rb-pill-edit" onclick="openRoomBookingModal(<?= htmlspecialchars(json_encode($b)) ?>,null,null)" title="Edit">✏️</button>
            <?php endif; ?>
            <?php if ($canCancel): ?>
            <button class="rb-pill-del" onclick="openRequestCancelModal(<?= $b['id'] ?>, '<?= addslashes($b['purpose']) ?>', '<?= $b['status'] ?>')" title="Request cancellation">✕</button>
            <?php endif; ?>
            <?php if ($canApproveThis): ?>
            <form method="POST" action="actions/booking.php" style="display:inline;margin-left:.25rem;">
                <input type="hidden" name="action" value="approve">
                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
                <button type="submit" class="btn btn-sm" style="padding:2px 8px;font-size:.75rem;background:#16a34a;color:#fff;border:none;" title="Approve">✓ Approve</button>
            </form>
            <button class="btn btn-sm btn-danger" style="padding:2px 8px;font-size:.75rem;" onclick="openRejectModal(<?= $b['id'] ?>, '<?= addslashes($b['booked_by_name']) ?>')" title="Reject">✕ Reject</button>
            <?php endif; ?>
            <?php if ($canApproveCancel): ?>
            <form method="POST" action="actions/booking.php" style="display:inline;margin-left:.25rem;">
                <input type="hidden" name="action" value="approve_cancel">
                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
                <button type="submit" class="btn btn-sm" style="padding:2px 8px;font-size:.75rem;background:#7c3aed;color:#fff;border:none;" title="Approve cancellation">✓ Allow Cancel</button>
            </form>
            <form method="POST" action="actions/booking.php" style="display:inline;">
                <input type="hidden" name="action" value="reject_cancel">
                <input type="hidden" name="id" value="<?= $b['id'] ?>">
                <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
                <button type="submit" class="btn btn-sm btn-danger" style="padding:2px 8px;font-size:.75rem;" title="Reject cancellation request">✕ Keep Booking</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endforeach; endif; ?>
    </div>

    <div class="rb-card-footer">
        <button class="rb-book-btn" onclick="openRoomBookingModal(null,<?= $rm['id'] ?>,null)">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
            Book <?= htmlspecialchars($rm['name']) ?>
        </button>
    </div>
</div>
<?php endforeach; ?>
</div>

<!-- BOOKING MODAL -->
<div class="modal" id="roomBookingModal">
    <div class="modal-box" style="max-width:540px;width:100%">
        <div class="modal-header">
            <h3 id="rbModalTitle">Book a Room</h3>
            <button class="modal-close" onclick="closeModal()">×</button>
        </div>
        <div id="rbConflictWarn" class="alert alert-warning" style="display:none;margin:1rem 1.5rem 0;">
            ⚠️ That time slot is already booked. Please choose a different time.
        </div>
        <div style="margin:1rem 1.5rem 0;padding:.75rem 1rem;background:#FFF3E0;border-radius:8px;font-size:.83rem;color:#7c4a00;border:1px solid #FBBF24;display:flex;align-items:flex-start;gap:.5rem;">
            <span>ℹ️</span>
            <span>Your booking will be submitted as <strong>Pending</strong> and requires approval from the room's Person-in-Charge before it is confirmed.</span>
        </div>
        <form method="POST" action="actions/booking.php">
            <input type="hidden" name="action"        id="rbAction" value="add">
            <input type="hidden" name="id"            id="rbId"     value="">
            <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">

            <div style="padding:1.25rem 1.5rem .5rem;">
                <label class="rb-modal-label">Choose a Room <span style="color:#1D9E75">*</span></label>
                <div class="rb-room-selector" id="rbRoomSelector">
                    <?php foreach ($rooms as $i2 => $rm2):
                        $clr2 = $colorMap[$rm2['color_class']] ?? $colorMap['room-blue'];
                        $emo2 = $roomEmojis[$i2 % count($roomEmojis)];
                    ?>
                    <div class="rb-room-opt" data-id="<?= $rm2['id'] ?>" onclick="selectRoomOption(this)">
                        <span class="rb-opt-dot" style="background:<?= $clr2['dot'] ?>"></span>
                        <?= $emo2 ?> <?= htmlspecialchars($rm2['name']) ?>
                        <?php if ($rm2['pic_name']): ?><small style="color:var(--muted);margin-left:.25rem;">(PIC: <?= htmlspecialchars($rm2['pic_name']) ?>)</small><?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <input type="hidden" name="room_id" id="rbRoomId" required>
            </div>

            <div class="form-grid" style="padding:.75rem 1.5rem 0;grid-template-columns:1fr 1fr 1fr;">
                <div class="form-group">
                    <label>Date <span style="color:#1D9E75">*</span></label>
                    <input type="date" name="booking_date" id="rbDate" value="<?= $viewDate ?>" required min="<?= date('Y-m-d') ?>" onchange="rbUpdateSummary();rbCheckConflict();rbBuildClockScrolls()">
                </div>
                <div class="form-group">
                    <label>Start Time <span style="color:#1D9E75">*</span></label>
                    <div class="clock-picker">
                        <div class="clock-display" id="rbStartDisplay" onclick="rbToggleClock('start')">
                            <span class="clock-icon">🕐</span>
                            <span id="rbStartVal">-- : --</span>
                            <span class="clock-caret">▾</span>
                        </div>
                        <div class="clock-dropdown" id="rbStartDrop" style="display:none">
                            <div class="clock-row">
                                <div class="clock-col"><div class="clock-label">Hour</div><div class="clock-scroll" id="rbStartHourScroll"></div></div>
                                <div class="clock-sep">:</div>
                                <div class="clock-col"><div class="clock-label">Minute</div><div class="clock-scroll" id="rbStartMinScroll"></div></div>
                            </div>
                            <div class="clock-confirm" onclick="rbConfirmClock('start')">Set Start Time</div>
                        </div>
                    </div>
                    <input type="hidden" name="start_time" id="rbStart" required>
                </div>
                <div class="form-group">
                    <label>End Time <span style="color:#1D9E75">*</span></label>
                    <div class="clock-picker">
                        <div class="clock-display" id="rbEndDisplay" onclick="rbToggleClock('end')">
                            <span class="clock-icon">🕑</span>
                            <span id="rbEndVal">-- : --</span>
                            <span class="clock-caret">▾</span>
                        </div>
                        <div class="clock-dropdown" id="rbEndDrop" style="display:none">
                            <div class="clock-row">
                                <div class="clock-col"><div class="clock-label">Hour</div><div class="clock-scroll" id="rbEndHourScroll"></div></div>
                                <div class="clock-sep">:</div>
                                <div class="clock-col"><div class="clock-label">Minute</div><div class="clock-scroll" id="rbEndMinScroll"></div></div>
                            </div>
                            <div class="clock-confirm" onclick="rbConfirmClock('end')">Set End Time</div>
                        </div>
                    </div>
                    <input type="hidden" name="end_time" id="rbEnd" required>
                </div>
            </div>

            <div style="padding:.75rem 1.5rem 0;">
                <div class="rb-modal-label" style="margin-bottom:.4rem;">Quick duration</div>
                <div class="rb-dur-pills">
                    <span class="rb-dur-pill" onclick="rbSetDuration(30,this)">30 min</span>
                    <span class="rb-dur-pill" onclick="rbSetDuration(60,this)">1 hour</span>
                    <span class="rb-dur-pill" onclick="rbSetDuration(90,this)">1.5 hrs</span>
                    <span class="rb-dur-pill" onclick="rbSetDuration(120,this)">2 hours</span>
                    <span class="rb-dur-pill" onclick="rbSetDuration(180,this)">Half day</span>
                </div>
            </div>

            <div class="rb-modal-summary" id="rbSummary" style="display:none;margin:1rem 1.5rem 0;"></div>

            <div class="form-grid" style="padding:1rem 1.5rem 0;grid-template-columns:1fr;">
                <div class="form-group">
                    <label>What's the meeting about? <span style="color:#1D9E75">*</span></label>
                    <textarea name="purpose" id="rbPurpose" rows="3" required placeholder="e.g. Team standup, Interview, Project review…" oninput="rbUpdateSummary()"></textarea>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-primary">Submit Booking Request</button>
            </div>
        </form>
    </div>
</div>

<!-- REQUEST CANCEL MODAL -->
<div class="modal" id="rbCancelModal">
    <div class="modal-box modal-sm">
        <div class="modal-header">
            <h3 id="rbCancelTitle">Request Cancellation</h3>
            <button class="modal-close" onclick="closeModal()">×</button>
        </div>
        <p style="padding:1.25rem 1.5rem 0;color:var(--muted);font-size:.875rem;" id="rbCancelDesc"></p>
        <div style="padding:.5rem 1.5rem 0;font-size:.82rem;color:#7c3aed;background:#faf5ff;margin:.75rem 1.5rem 0;border-radius:8px;padding:.75rem 1rem;border:1px solid #ddd6fe;">
            <span id="rbCancelNote">⚠️ This will submit a <strong>cancellation request</strong> to the PIC for approval. Your slot remains held until approved.</span>
        </div>
        <form method="POST" action="actions/booking.php">
            <input type="hidden" name="action" value="request_cancel">
            <input type="hidden" name="id" id="rbCancelId" value="">
            <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
            <div style="padding:.75rem 1.5rem 0;">
                <label style="font-size:.85rem;font-weight:600;display:block;margin-bottom:.4rem;">Reason for cancellation <span style="font-weight:400;color:var(--muted)">(optional)</span></label>
                <input type="text" name="cancel_reason" placeholder="e.g. Meeting rescheduled, no longer needed…" style="width:100%">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Keep It</button>
                <button type="submit" class="btn btn-danger" id="rbCancelSubmitBtn">Request Cancellation</button>
            </div>
        </form>
    </div>
</div>

<!-- REJECT MODAL -->
<div class="modal" id="rbRejectModal">
    <div class="modal-box modal-sm">
        <div class="modal-header">
            <h3>Reject Booking</h3>
            <button class="modal-close" onclick="closeModal()">×</button>
        </div>
        <p style="padding:1.25rem 1.5rem 0;color:var(--muted);font-size:.85rem;" id="rbRejectDesc"></p>
        <form method="POST" action="actions/booking.php">
            <input type="hidden" name="action" value="reject">
            <input type="hidden" name="id" id="rbRejectId" value="">
            <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
            <div style="padding:.75rem 1.5rem 0;">
                <label style="font-size:.85rem;font-weight:600;display:block;margin-bottom:.4rem;">Reason <span style="font-weight:400;color:var(--muted)">(optional)</span></label>
                <input type="text" name="rejection_reason" placeholder="e.g. Room unavailable, conflicting event…" style="width:100%">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="closeModal()">Cancel</button>
                <button type="submit" class="btn btn-danger">Confirm Rejection</button>
            </div>
        </form>
    </div>
</div>

<?php if (isAdminIT()): ?>
<!-- MANAGE ROOMS MODAL -->
<div class="modal" id="manageRoomsModal">
    <div class="modal-box" style="max-width:600px;width:100%">
        <div class="modal-header">
            <h3>Manage Rooms</h3>
            <button class="modal-close" onclick="closeModal()">×</button>
        </div>
        <div style="padding:1rem 1.5rem 0;">
            <div id="manageRoomsList">
                <?php foreach ($rooms as $idx => $rm):
                    $clr = $colorMap[$rm['color_class']] ?? $colorMap['room-blue'];
                    $emo = $roomEmojis[$idx % count($roomEmojis)];
                ?>
                <div class="mrm-room-row" id="mrm-row-<?= $rm['id'] ?>">
                    <div class="mrm-room-dot" style="background:<?= $clr['light'] ?>"><?= $emo ?></div>
                    <div class="mrm-room-detail">
                        <strong><?= htmlspecialchars($rm['name']) ?></strong>
                        <span>👥 <?= (int)$rm['capacity'] ?> seats<?= $rm['description'] ? ' · '.htmlspecialchars($rm['description']) : '' ?>
                        <?= $rm['pic_name'] ? ' · 🔑 '.htmlspecialchars($rm['pic_name']) : ' · <em style="color:var(--muted)">No PIC</em>' ?></span>
                    </div>
                    <div class="mrm-row-actions">
                        <button class="btn btn-outline btn-sm" onclick="openEditRoomForm(<?= htmlspecialchars(json_encode($rm)) ?>)">Edit</button>
                        <button class="btn btn-sm mrm-del-btn" onclick="openDeleteRoomConfirm(<?= $rm['id'] ?>, '<?= addslashes($rm['name']) ?>')">Delete</button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div style="padding:.75rem 1.5rem 0;">
            <div style="border-top:1px solid var(--border);padding-top:1rem;">
                <div id="mrmFormTitle" style="font-weight:700;font-size:.875rem;margin-bottom:.75rem;">Add New Room</div>
                <form method="POST" action="actions/booking.php" id="mrmRoomForm">
                    <input type="hidden" name="action"        id="mrmAction"   value="add_room">
                    <input type="hidden" name="room_id"       id="mrmRoomId"   value="">
                    <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
                    <div class="form-grid" style="grid-template-columns:1fr 1fr;gap:.75rem;">
                        <div class="form-group" style="grid-column:1/3;">
                            <label>Room Name <span style="color:#1D9E75">*</span></label>
                            <input type="text" name="room_name" id="mrmName" placeholder="e.g. Boardroom A" required>
                        </div>
                        <div class="form-group">
                            <label>Capacity <span style="color:#1D9E75">*</span></label>
                            <input type="number" name="room_capacity" id="mrmCapacity" min="1" max="200" placeholder="e.g. 10" required>
                        </div>
                        <div class="form-group">
                            <label>Colour</label>
                            <select name="room_color" id="mrmColor">
                                <option value="room-blue">🔵 Blue</option>
                                <option value="room-green">🟢 Green</option>
                                <option value="room-yellow">🟡 Yellow</option>
                                <option value="room-red">🔴 Red</option>
                                <option value="room-purple">🟣 Purple</option>
                                <option value="room-orange">🟠 Orange</option>
                            </select>
                        </div>
                        <div class="form-group" style="grid-column:1/3;">
                            <label>Description <span style="color:var(--muted);font-weight:400">(optional)</span></label>
                            <input type="text" name="room_description" id="mrmDesc" placeholder="e.g. Projector, video conferencing">
                        </div>
                        <div class="form-group" style="grid-column:1/3;">
                            <label>Person-in-Charge (PIC)</label>
                            <select name="room_pic" id="mrmPic">
                                <option value="">— No PIC assigned —</option>
                                <?php foreach ($allUsers as $u): ?>
                                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?><?= $u['staff_no'] ? ' ('.$u['staff_no'].')' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                            <small style="color:var(--muted);font-size:.78rem;">PIC receives a notification badge and can approve/reject bookings for this room. One staff can manage multiple rooms.</small>
                        </div>
                    </div>
                    <div class="modal-footer" style="padding:1rem 0 0;border:none;justify-content:flex-start;gap:.5rem;">
                        <button type="submit" class="btn btn-primary" id="mrmSubmitBtn">Add Room</button>
                        <button type="button" class="btn btn-ghost" id="mrmCancelEdit" style="display:none" onclick="resetMrmForm()">Cancel Edit</button>
                    </div>
                </form>
            </div>
        </div>
        <div style="padding:.5rem 1.5rem 1.5rem;"></div>
    </div>
</div>

<!-- DELETE ROOM -->
<div class="modal" id="deleteRoomModal">
    <div class="modal-box modal-sm">
        <div class="modal-header">
            <h3>Delete Room</h3>
            <button class="modal-close" onclick="closeModal()">×</button>
        </div>
        <p style="padding:1.25rem 1.5rem 0;color:var(--muted);font-size:.875rem;">
            Delete <strong id="deleteRoomName"></strong>? All bookings for this room will also be removed.
        </p>
        <form method="POST" action="actions/booking.php">
            <input type="hidden" name="action"        value="delete_room">
            <input type="hidden" name="room_id"       id="deleteRoomId" value="">
            <input type="hidden" name="redirect_date" value="<?= $viewDate ?>">
            <div class="modal-footer">
                <button type="button" class="btn btn-ghost" onclick="openModal('manageRoomsModal')">Cancel</button>
                <button type="submit" class="btn btn-danger">Yes, Delete Room</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<style>
/* Digital clock picker */
.clock-picker { position: relative; }
.clock-display {
  display: flex; align-items: center; gap: .5rem;
  border: 1.5px solid var(--border,#e2e8f0); border-radius: 8px; padding: .55rem .75rem;
  cursor: pointer; font-size: .95rem; font-weight: 600; color: var(--text,#1e293b);
  background: var(--surface,#fff); transition: border-color .15s;
}
.clock-display:hover, .clock-display.open { border-color: #6366f1; }
.clock-icon { font-size: 1rem; }
.clock-caret { margin-left:auto; font-size:.7rem; color:var(--muted,#94a3b8); }
.clock-dropdown {
  position: absolute; top: calc(100% + 4px); left: 0; z-index: 1100;
  background: var(--surface,#fff); border: 1.5px solid var(--border,#e2e8f0); border-radius: 12px;
  box-shadow: 0 8px 30px rgba(0,0,0,.15); padding: 1rem; min-width: 200px;
}
.clock-row { display: flex; gap: .5rem; align-items: flex-start; }
.clock-col  { flex: 1; }
.clock-label { font-size: .7rem; font-weight: 700; color: var(--muted,#94a3b8); text-align: center; text-transform: uppercase; letter-spacing: .05em; margin-bottom: .3rem; }
.clock-sep   { font-size: 1.4rem; font-weight: 700; color: #6366f1; padding-top: 1.8rem; }
.clock-scroll {
  max-height: 150px; overflow-y: auto; border: 1px solid var(--border,#e2e8f0); border-radius: 8px;
  scrollbar-width: thin;
}
.clock-scroll::-webkit-scrollbar { width: 4px; }
.clock-scroll::-webkit-scrollbar-thumb { background: #c7d2fe; border-radius: 4px; }
.clock-num {
  padding: .42rem .5rem; text-align: center; font-size: .88rem; font-weight: 500;
  cursor: pointer; border-radius: 4px; margin: 1px; transition: background .1s;
}
.clock-num:hover    { background: #eef2ff; color: #6366f1; }
.clock-num.selected { background: #6366f1; color: #fff; font-weight: 700; }
.clock-num.disabled { opacity: 0.3; cursor: not-allowed; text-decoration: line-through; pointer-events: none; }
.clock-num.booked   { background: #fee2e2 !important; color: #991b1b !important; font-size: .72rem; }
.clock-num.booked::after { content: " ✕"; }
.clock-confirm {
  margin-top: .65rem; text-align: center; background: #6366f1; color: #fff;
  border-radius: 8px; padding: .5rem; font-size: .82rem; font-weight: 600;
  cursor: pointer; transition: background .15s;
}
.clock-confirm:hover { background: #4f46e5; }
</style>

<script>
const rbBookings = <?= json_encode(array_values($dayBookings)) ?>;
const rbRooms    = <?= json_encode(array_values($rooms)) ?>;
const rbViewDate = '<?= $viewDate ?>';
// Session pending booking (from guest flow after login)
const rbSessionBooking = <?= json_encode($sessionBooking) ?>;

// ── Time helpers ─────────────────────────────────────────────────────
function rbToMin(t) { if (!t) return 0; const [h,m] = t.substring(0,5).split(':').map(Number); return h*60+m; }
function rbGetNowMin() { const n = new Date(); return n.getHours()*60+n.getMinutes(); }
function rbIsToday(date) { return date === new Date().toISOString().slice(0,10); }

function rbIsStartDisabled(h, m, roomId, date, editId) {
    const tMin = h*60+m;
    if (rbIsToday(date) && tMin <= rbGetNowMin()) return true;
    if (!roomId || !date) return false;
    return rbBookings.some(b =>
        b.room_id == roomId && b.booking_date === date &&
        !['Rejected'].includes(b.status) &&
        (!editId || b.id != editId) &&
        tMin >= rbToMin(b.start_time) && tMin < rbToMin(b.end_time)
    );
}

function rbIsEndDisabled(h, m, roomId, date, editId) {
    const tMin = h*60+m;
    const startH = rbClockState.start.h, startM = rbClockState.start.m;
    const startMin = (startH !== null && startM !== null) ? startH*60+startM : null;
    if (startMin !== null && tMin <= startMin) return true;
    if (rbIsToday(date) && tMin <= rbGetNowMin()) return true;
    if (startMin !== null && roomId && date) {
        return rbBookings.some(b =>
            b.room_id == roomId && b.booking_date === date &&
            !['Rejected'].includes(b.status) &&
            (!editId || b.id != editId) &&
            startMin < rbToMin(b.end_time) && tMin > rbToMin(b.start_time)
        );
    }
    return false;
}

// ── Digital Clock Picker ─────────────────────────────────────────────
let rbClockState = { start:{h:null,m:null}, end:{h:null,m:null} };

function rbBuildClockScrolls() {
    const roomId = document.getElementById('rbRoomId').value;
    const date   = document.getElementById('rbDate').value;
    const editId = document.getElementById('rbId').value;

    ['start','end'].forEach(w => {
        const cap = w.charAt(0).toUpperCase()+w.slice(1);
        const hEl = document.getElementById('rb'+cap+'HourScroll');
        const mEl = document.getElementById('rb'+cap+'MinScroll');
        if (!hEl || !mEl) return;
        hEl.innerHTML = ''; mEl.innerHTML = '';

        // Build hours — disable if all 4 quarter-slots are unavailable
        for (let h = 7; h <= 20; h++) {
            const allOff = [0,15,30,45].every(m =>
                w === 'start' ? rbIsStartDisabled(h,m,roomId,date,editId)
                              : rbIsEndDisabled(h,m,roomId,date,editId)
            );
            const d = document.createElement('div');
            d.className = 'clock-num' + (allOff ? ' disabled' : '');
            d.textContent = String(h).padStart(2,'0');
            if (!allOff) d.onclick = () => rbSelectClockNum(w, 'h', h, d);
            hEl.appendChild(d);
        }

        // Build minutes with data attribute; states refresh on hour selection
        [0,15,30,45].forEach(m => {
            const d = document.createElement('div');
            d.className = 'clock-num';
            d.textContent = String(m).padStart(2,'0');
            d.dataset.minute = m;
            d.onclick = function() {
                if (!this.classList.contains('disabled')) rbSelectClockNum(w, 'm', m, d);
            };
            mEl.appendChild(d);
        });
    });
}

function rbRefreshMinutes(which) {
    const cap    = which.charAt(0).toUpperCase()+which.slice(1);
    const h      = rbClockState[which].h;
    if (h === null) return;
    const roomId = document.getElementById('rbRoomId').value;
    const date   = document.getElementById('rbDate').value;
    const editId = document.getElementById('rbId').value;
    const mEl    = document.getElementById('rb'+cap+'MinScroll');
    mEl.querySelectorAll('.clock-num').forEach(el => {
        const m = parseInt(el.dataset.minute);
        const off = which === 'start'
            ? rbIsStartDisabled(h, m, roomId, date, editId)
            : rbIsEndDisabled(h, m, roomId, date, editId);
        el.classList.toggle('disabled', off);
        el.onclick = off ? null : () => rbSelectClockNum(which, 'm', m, el);
        // Keep selected state if value still valid
        if (off && el.classList.contains('selected')) {
            el.classList.remove('selected');
            rbClockState[which].m = null;
            document.getElementById('rb'+(which==='start'?'Start':'End')).value = '';
            document.getElementById('rb'+cap+'Val').textContent = '-- : --';
        }
    });
}

function rbSelectClockNum(which, part, val, el) {
    const cap = which.charAt(0).toUpperCase()+which.slice(1);
    const scrollId = 'rb'+cap+(part==='h'?'HourScroll':'MinScroll');
    document.querySelectorAll('#'+scrollId+' .clock-num').forEach(x => x.classList.remove('selected'));
    el.classList.add('selected');
    rbClockState[which][part] = val;
    if (part === 'h') {
        // Refresh minute options for this field when hour changes
        rbRefreshMinutes(which);
        // When start hour changes, also refresh end time minutes
        if (which === 'start') rbRefreshMinutes('end');
    }
    const h = rbClockState[which].h, m = rbClockState[which].m;
    if (h !== null && m !== null) {
        const t = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
        document.getElementById('rb'+cap+'Val').textContent = t;
        document.getElementById('rb'+(which==='start'?'Start':'End')).value = t;
        // When start time changes, refresh end hour scroll too
        if (which === 'start') rbBuildClockScrolls();
        rbCheckConflict(); rbUpdateSummary();
    }
}

function rbToggleClock(which) {
    const cap = which.charAt(0).toUpperCase()+which.slice(1);
    const drop = document.getElementById('rb'+cap+'Drop');
    const disp = document.getElementById('rb'+cap+'Display');
    const isOpen = drop.style.display !== 'none';
    // Close all
    ['start','end'].forEach(w => {
        const c = w.charAt(0).toUpperCase()+w.slice(1);
        const d = document.getElementById('rb'+c+'Drop');
        if (d) d.style.display = 'none';
        const dd = document.getElementById('rb'+c+'Display');
        if (dd) dd.classList.remove('open');
    });
    if (!isOpen) { drop.style.display='block'; disp.classList.add('open'); }
}

function rbConfirmClock(which) {
    const cap = which.charAt(0).toUpperCase()+which.slice(1);
    document.getElementById('rb'+cap+'Drop').style.display = 'none';
    document.getElementById('rb'+cap+'Display').classList.remove('open');
    // Auto-fill end = start+1h if end not yet set
    if (which === 'start' && rbClockState.start.h !== null && rbClockState.end.h === null) {
        const eh = Math.min(rbClockState.start.h+1, 20);
        const em = rbClockState.start.m;
        rbSetClockValue('end', eh, em);
    }
}

function rbSetClockValue(which, h, m) {
    rbClockState[which] = {h, m};
    const cap = which.charAt(0).toUpperCase()+which.slice(1);
    const t = String(h).padStart(2,'0')+':'+String(m).padStart(2,'0');
    const dispEl = document.getElementById('rb'+cap+'Val');
    if (dispEl) dispEl.textContent = t;
    document.getElementById('rb'+(which==='start'?'Start':'End')).value = t;
    // Highlight selections
    const hScrollId = 'rb'+cap+'HourScroll';
    const mScrollId = 'rb'+cap+'MinScroll';
    document.querySelectorAll('#'+hScrollId+' .clock-num').forEach(x => x.classList.toggle('selected', parseInt(x.textContent)===h));
    document.querySelectorAll('#'+mScrollId+' .clock-num').forEach(x => x.classList.toggle('selected', parseInt(x.textContent)===m));
    rbCheckConflict(); rbUpdateSummary();
}

// Close clock dropdowns on outside click
document.addEventListener('click', e => {
    if (!e.target.closest('.clock-picker')) {
        ['start','end'].forEach(w => {
            const c = w.charAt(0).toUpperCase()+w.slice(1);
            const d = document.getElementById('rb'+c+'Drop');
            if (d) d.style.display='none';
            const dd = document.getElementById('rb'+c+'Display');
            if (dd) dd.classList.remove('open');
        });
    }
});

// ── Booking Modal ────────────────────────────────────────────────────
function selectRoomOption(el) {
    document.querySelectorAll('.rb-room-opt').forEach(o => o.classList.remove('selected'));
    el.classList.add('selected');
    document.getElementById('rbRoomId').value = el.dataset.id;
    rbBuildClockScrolls();
    rbCheckConflict(); rbUpdateSummary();
}

function rbResetClockUI() {
    rbClockState = {start:{h:null,m:null},end:{h:null,m:null}};
    ['Start','End'].forEach(cap => {
        const v = document.getElementById('rb'+cap+'Val');
        if (v) v.textContent='-- : --';
    });
    document.querySelectorAll('.clock-num').forEach(x => x.classList.remove('selected'));
}

function openRoomBookingModal(data, preRoomId, preTime) {
    document.getElementById('rbConflictWarn').style.display = 'none';
    document.getElementById('rbSummary').style.display = 'none';
    document.querySelectorAll('.rb-dur-pill').forEach(p => p.classList.remove('active'));
    rbBuildClockScrolls();
    rbResetClockUI();

    if (data) {
        document.getElementById('rbModalTitle').textContent = 'Edit Booking';
        document.getElementById('rbAction').value = 'edit';
        document.getElementById('rbId').value     = data.id;
        document.getElementById('rbDate').value   = data.booking_date;
        document.getElementById('rbPurpose').value= data.purpose;
        document.querySelectorAll('.rb-room-opt').forEach(o => o.classList.toggle('selected', o.dataset.id == data.room_id));
        document.getElementById('rbRoomId').value = data.room_id;
        // Set clock values
        const [sh,sm] = (data.start_time||'00:00').substring(0,5).split(':').map(Number);
        const [eh,em] = (data.end_time||'00:00').substring(0,5).split(':').map(Number);
        rbSetClockValue('start', sh, sm);
        rbSetClockValue('end',   eh, em);
    } else {
        document.getElementById('rbModalTitle').textContent = 'Book a Room';
        document.getElementById('rbAction').value = 'add';
        document.getElementById('rbId').value     = '';
        document.getElementById('rbDate').value   = rbViewDate;
        document.getElementById('rbStart').value  = '';
        document.getElementById('rbEnd').value    = '';
        document.getElementById('rbPurpose').value= '';
        document.querySelectorAll('.rb-room-opt').forEach(o => o.classList.toggle('selected', preRoomId && o.dataset.id == preRoomId));
        document.getElementById('rbRoomId').value = preRoomId || '';
        if (preTime) {
            const [h,m] = preTime.split(':').map(Number);
            rbSetClockValue('start', h, m);
            rbSetClockValue('end',   Math.min(h+1,20), m);
        }
    }
    rbUpdateSummary();
    openModal('roomBookingModal');
}

function quickBookNow() {
    const now = new Date();
    const mins = now.getHours()*60+now.getMinutes();
    const rounded = Math.ceil(mins/30)*30;
    const sh = Math.floor(rounded/60), sm = rounded%60;
    const eh = Math.floor((rounded+60)/60), em = (rounded+60)%60;
    const startStr = String(sh).padStart(2,'0')+':'+String(sm).padStart(2,'0');
    const freeRoom = rbRooms.find(r => !rbBookings.some(b =>
        b.room_id == r.id && b.booking_date === rbViewDate &&
        !['Rejected'].includes(b.status) &&
        startStr < (b.end_time||'').substring(0,5) &&
        String(eh).padStart(2,'0')+':'+String(em).padStart(2,'0') > (b.start_time||'').substring(0,5)
    ));
    rbBuildClockScrolls();
    rbResetClockUI();
    openRoomBookingModal(null, freeRoom ? freeRoom.id : rbRooms[0].id, null);
    rbSetClockValue('start', sh, sm);
    rbSetClockValue('end',   Math.min(eh,20), em);
    rbUpdateSummary();
}

function openRequestCancelModal(id, purpose, status) {
    document.getElementById('rbCancelId').value = id;
    document.getElementById('rbCancelDesc').textContent =
        'Requesting cancellation for: "' + purpose + '"';
    if (status === 'Pending') {
        document.getElementById('rbCancelNote').innerHTML =
            'ℹ️ This is a <strong>Pending</strong> booking. Cancellation request will be sent to the PIC for approval.';
    } else {
        document.getElementById('rbCancelNote').innerHTML =
            '⚠️ This is an <strong>Approved</strong> booking. The PIC must approve your cancellation before the slot is released.';
    }
    openModal('rbCancelModal');
}

function openRejectModal(id, bookedBy) {
    document.getElementById('rbRejectId').value = id;
    document.getElementById('rbRejectDesc').textContent = 'Rejecting booking by ' + bookedBy + '. You may optionally provide a reason below.';
    openModal('rbRejectModal');
}

function rbSetDuration(mins, el) {
    document.querySelectorAll('.rb-dur-pill').forEach(p => p.classList.remove('active'));
    el.classList.add('active');
    const st = document.getElementById('rbStart').value;
    if (!st) return;
    const [h,m] = st.split(':').map(Number);
    const endMin = h*60+m+mins;
    if (endMin <= 20*60) {
        rbSetClockValue('end', Math.floor(endMin/60), endMin%60);
    }
}

function rbCheckConflict() {
    const rid    = document.getElementById('rbRoomId').value;
    const date   = document.getElementById('rbDate').value;
    const start  = document.getElementById('rbStart').value;
    const end    = document.getElementById('rbEnd').value;
    const editId = document.getElementById('rbId').value;
    if (!rid||!date||!start||!end) return;
    const conflict = rbBookings.some(b =>
        b.room_id == rid && b.booking_date === date &&
        !['Rejected'].includes(b.status) &&
        (!editId || b.id != editId) &&
        start < (b.end_time||'').substring(0,5) && end > (b.start_time||'').substring(0,5)
    );
    document.getElementById('rbConflictWarn').style.display = conflict ? 'block' : 'none';
}

function openEditRoomForm(rm) {
    document.getElementById('mrmFormTitle').textContent = 'Edit Room';
    document.getElementById('mrmAction').value   = 'edit_room';
    document.getElementById('mrmRoomId').value   = rm.id;
    document.getElementById('mrmName').value     = rm.name;
    document.getElementById('mrmCapacity').value = rm.capacity;
    document.getElementById('mrmColor').value    = rm.color_class;
    document.getElementById('mrmDesc').value     = rm.description || '';
    document.getElementById('mrmPic').value      = rm.pic_user_id || '';
    document.getElementById('mrmSubmitBtn').textContent = 'Save Changes';
    document.getElementById('mrmCancelEdit').style.display = 'inline-flex';
}

function resetMrmForm() {
    document.getElementById('mrmFormTitle').textContent = 'Add New Room';
    document.getElementById('mrmAction').value   = 'add_room';
    document.getElementById('mrmRoomId').value   = '';
    document.getElementById('mrmRoomForm').reset();
    document.getElementById('mrmSubmitBtn').textContent = 'Add Room';
    document.getElementById('mrmCancelEdit').style.display = 'none';
}

function openDeleteRoomConfirm(id, name) {
    document.getElementById('deleteRoomId').value = id;
    document.getElementById('deleteRoomName').textContent = name;
    openModal('deleteRoomModal');
}

function rbUpdateSummary() {
    const rid  = document.getElementById('rbRoomId').value;
    const date = document.getElementById('rbDate').value;
    const start= document.getElementById('rbStart').value;
    const end  = document.getElementById('rbEnd').value;
    const purp = document.getElementById('rbPurpose').value.trim();
    const el   = document.getElementById('rbSummary');
    if (!rid||!date||!start||!end) { el.style.display='none'; return; }
    const rm = rbRooms.find(r => r.id == rid);
    if (!rm) { el.style.display='none'; return; }
    const [sh,sm] = start.split(':').map(Number);
    const [eh,em] = end.split(':').map(Number);
    const d = (eh*60+em)-(sh*60+sm);
    const dur = d>0 ? (Math.floor(d/60)?(Math.floor(d/60)+'h '):'')+(d%60?(d%60+'m'):'') : '';
    el.innerHTML = '<strong>'+rm.name+'</strong> · '+date+' · '+start+'–'+end+(dur?' ('+dur.trim()+')':'')+(purp?'<br><span style="color:var(--muted)">"'+purp.substring(0,70)+(purp.length>70?'…':'')+'\"</span>':'');
    el.style.display = 'block';
}

// ── Auto-open booking modal from session (guest → login flow) ────────
document.addEventListener('DOMContentLoaded', () => {
    <?php if (isset($_GET['open_booking']) && $sessionBooking): ?>
    // Restore pending booking from guest page
    const sb = rbSessionBooking;
    if (sb) {
        rbBuildClockScrolls();
        rbResetClockUI();
        // Pre-select room
        document.querySelectorAll('.rb-room-opt').forEach(o => o.classList.toggle('selected', o.dataset.id == sb.room_id));
        document.getElementById('rbRoomId').value  = sb.room_id;
        document.getElementById('rbDate').value    = sb.booking_date;
        document.getElementById('rbPurpose').value = sb.purpose;
        document.getElementById('rbAction').value  = 'add';
        document.getElementById('rbId').value      = '';
        document.getElementById('rbModalTitle').textContent = 'Confirm Your Booking';
        const [sh,sm] = sb.start_time.split(':').map(Number);
        const [eh,em] = sb.end_time.split(':').map(Number);
        rbSetClockValue('start', sh, sm);
        rbSetClockValue('end',   eh, em);
        rbUpdateSummary();
        // Show a notice
        const noticeDiv = document.getElementById('rbConflictWarn');
        noticeDiv.style.display = 'none';
        openModal('roomBookingModal');
        // Add a welcome note inside the modal
        const info = document.querySelector('#roomBookingModal .alert-warning + div, #roomBookingModal div[style*="FFF3E0"]');
        const welcomeEl = document.createElement('div');
        welcomeEl.style.cssText = 'margin:1rem 1.5rem 0;padding:.75rem 1rem;background:#d1fae5;border-radius:8px;font-size:.83rem;color:#065f46;border:1px solid #6ee7b7;';
        welcomeEl.innerHTML = '✅ <strong>Welcome back!</strong> Your booking details have been restored. Please confirm below.';
        document.querySelector('#roomBookingModal .modal-box').insertBefore(welcomeEl,
            document.querySelector('#roomBookingModal form'));
    }
    <?php endif; ?>
});
</script>
