<?php
// includes/migrate.php — Safe column-by-column migration helper
function migrateBookingColumns($pdo) {
    $cols = [
        'status'           => "ALTER TABLE `room_bookings` ADD COLUMN `status` ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending'",
        'approved_by_id'   => "ALTER TABLE `room_bookings` ADD COLUMN `approved_by_id` int(11) DEFAULT NULL",
        'approved_by_name' => "ALTER TABLE `room_bookings` ADD COLUMN `approved_by_name` varchar(100) DEFAULT NULL",
        'approved_at'      => "ALTER TABLE `room_bookings` ADD COLUMN `approved_at` timestamp NULL DEFAULT NULL",
        'rejection_reason' => "ALTER TABLE `room_bookings` ADD COLUMN `rejection_reason` varchar(255) DEFAULT NULL",
    ];
    foreach ($cols as $col => $sql) {
        try { $pdo->query("SELECT `$col` FROM room_bookings LIMIT 1"); }
        catch (PDOException $e) { $pdo->exec($sql); }
    }
    // Fix any NULLs from partial migration
    try { $pdo->exec("UPDATE room_bookings SET status='Pending' WHERE status IS NULL"); }
    catch (PDOException $e) {}

    // meeting_rooms PIC column
    try { $pdo->query("SELECT pic_user_id FROM meeting_rooms LIMIT 1"); }
    catch (PDOException $e) { $pdo->exec("ALTER TABLE `meeting_rooms` ADD COLUMN `pic_user_id` int(11) DEFAULT NULL"); }

    // cancel_reason column for cancellation requests
    try { $pdo->query("SELECT cancel_reason FROM room_bookings LIMIT 1"); }
    catch (PDOException $e) { $pdo->exec("ALTER TABLE `room_bookings` ADD COLUMN `cancel_reason` varchar(255) DEFAULT NULL"); }

    // Extend status ENUM to include CancelRequested
    try {
        $pdo->exec("ALTER TABLE `room_bookings` MODIFY COLUMN `status` ENUM('Pending','Approved','Rejected','CancelRequested') NOT NULL DEFAULT 'Pending'");
    } catch (PDOException $e) {}
}
